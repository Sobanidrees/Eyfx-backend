import { MigrationInterface, QueryRunner } from "typeorm";

export class CreateServiceRequestTable1702382557163 implements MigrationInterface {
    name = 'CreateServiceRequestTable1702382557163'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TYPE "public"."service_request_packagetype_enum" AS ENUM('Basic', 'Premium')`);
        await queryRunner.query(`CREATE TYPE "public"."service_request_status_enum" AS ENUM('Requested', 'Pending', 'InProgress', 'Completed', 'ReportShared')`);
        await queryRunner.query(`CREATE TABLE "service_request" ("id" SERIAL NOT NULL, "time" character varying NOT NULL, "packageType" "public"."service_request_packagetype_enum" NOT NULL DEFAULT 'Basic', "status" "public"."service_request_status_enum" NOT NULL DEFAULT 'Requested', "date" character varying NOT NULL, "createdAt" TIMESTAMP NOT NULL DEFAULT ('now'::text)::timestamp(6) with time zone, "updatedAt" TIMESTAMP NOT NULL DEFAULT ('now'::text)::timestamp(6) with time zone, "consumerId" integer, "vehicleId" integer, "serviceId" integer, "inspectorId" integer, CONSTRAINT "PK_08446fa58294cb2dd0b6ff9e5a7" PRIMARY KEY ("id"))`);
        await queryRunner.query(`ALTER TABLE "service_request" ADD CONSTRAINT "FK_8caaefffd27fca39c0d9f3ba7a0" FOREIGN KEY ("consumerId") REFERENCES "consumer"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "service_request" ADD CONSTRAINT "FK_da4d380645c9b1f85ae3eb53960" FOREIGN KEY ("vehicleId") REFERENCES "vehicle"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "service_request" ADD CONSTRAINT "FK_595df1b6d886ee96db2642f9b3e" FOREIGN KEY ("serviceId") REFERENCES "service"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "service_request" ADD CONSTRAINT "FK_735ffc665d52c3c7b97beaf9433" FOREIGN KEY ("inspectorId") REFERENCES "inspector"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "service_request" DROP CONSTRAINT "FK_735ffc665d52c3c7b97beaf9433"`);
        await queryRunner.query(`ALTER TABLE "service_request" DROP CONSTRAINT "FK_595df1b6d886ee96db2642f9b3e"`);
        await queryRunner.query(`ALTER TABLE "service_request" DROP CONSTRAINT "FK_da4d380645c9b1f85ae3eb53960"`);
        await queryRunner.query(`ALTER TABLE "service_request" DROP CONSTRAINT "FK_8caaefffd27fca39c0d9f3ba7a0"`);
        await queryRunner.query(`DROP TABLE "service_request"`);
        await queryRunner.query(`DROP TYPE "public"."service_request_status_enum"`);
        await queryRunner.query(`DROP TYPE "public"."service_request_packagetype_enum"`);
    }
}
