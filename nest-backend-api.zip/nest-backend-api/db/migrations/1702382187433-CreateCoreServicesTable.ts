import { MigrationInterface, QueryRunner } from "typeorm";

export class CreateCoreServicesTable1702382187433 implements MigrationInterface {
    name = 'CreateCoreServicesTable1702382187433'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TYPE "public"."core_service_packagetype_enum" AS ENUM('Basic', 'Premium')`);
        await queryRunner.query(`CREATE TABLE "core_service" ("id" SERIAL NOT NULL, "coreServiceName" character varying NOT NULL, "packageType" "public"."core_service_packagetype_enum" NOT NULL DEFAULT 'Basic', "created_at" TIMESTAMP NOT NULL DEFAULT ('now'::text)::timestamp(6) with time zone, "updated_at" TIMESTAMP NOT NULL DEFAULT ('now'::text)::timestamp(6) with time zone, "serviceId" integer, CONSTRAINT "UQ_71da78c9d0b4e05668087c4440d" UNIQUE ("coreServiceName"), CONSTRAINT "PK_eb462f8fbcf7c94aa457a6e903d" PRIMARY KEY ("id"))`);
        await queryRunner.query(`ALTER TABLE "core_service" ADD CONSTRAINT "FK_6b44225f6147e90ea5e871e8b6c" FOREIGN KEY ("serviceId") REFERENCES "service"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "core_service" DROP CONSTRAINT "FK_6b44225f6147e90ea5e871e8b6c"`);
        await queryRunner.query(`DROP TABLE "core_service"`);
        await queryRunner.query(`DROP TYPE "public"."core_service_packagetype_enum"`);
    }
}
