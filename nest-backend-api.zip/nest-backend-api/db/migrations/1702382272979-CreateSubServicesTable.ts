import { MigrationInterface, QueryRunner } from "typeorm";

export class CreateSubServicesTable1702382272979 implements MigrationInterface {
    name = 'CreateSubServicesTable1702382272979'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TABLE "sub_services" ("id" SERIAL NOT NULL, "subServiceName" character varying NOT NULL, "parentId" integer, "created_at" TIMESTAMP NOT NULL DEFAULT ('now'::text)::timestamp(6) with time zone, "updated_at" TIMESTAMP NOT NULL DEFAULT ('now'::text)::timestamp(6) with time zone, "imageable" boolean NOT NULL, "coreServicesId" integer, CONSTRAINT "UQ_1e0a0778fdff3f7ffa6955faff0" UNIQUE ("subServiceName"), CONSTRAINT "PK_8d0808cbbab4fad02bc41183a70" PRIMARY KEY ("id"))`);
        await queryRunner.query(`ALTER TABLE "sub_services" ADD CONSTRAINT "FK_fbefd53aa4f03a3e243d532aa09" FOREIGN KEY ("coreServicesId") REFERENCES "core_service"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "sub_services" DROP CONSTRAINT "FK_fbefd53aa4f03a3e243d532aa09"`);
        await queryRunner.query(`DROP TABLE "sub_services"`);
    }
}
