import { MigrationInterface, QueryRunner } from "typeorm";

export class CreateServiceMetadataTable1702382685755 implements MigrationInterface {
    name = 'CreateServiceMetadataTable1702382685755'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TABLE "serviceMetaData" ("id" SERIAL NOT NULL, "coreServiceName" character varying NOT NULL, "status" character varying NOT NULL, "created_at" TIMESTAMP NOT NULL DEFAULT ('now'::text)::timestamp(6) with time zone, "updated_at" TIMESTAMP NOT NULL DEFAULT ('now'::text)::timestamp(6) with time zone, "serviceRequestId" integer, CONSTRAINT "PK_256842d7f9a757412ff6f148bc3" PRIMARY KEY ("id"))`);
        await queryRunner.query(`ALTER TABLE "serviceMetaData" ADD CONSTRAINT "FK_111e3db27c22dfa2b15f20f1809" FOREIGN KEY ("serviceRequestId") REFERENCES "service_request"("id") ON DELETE SET NULL ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "serviceMetaData" DROP CONSTRAINT "FK_111e3db27c22dfa2b15f20f1809"`);
        await queryRunner.query(`DROP TABLE "serviceMetaData"`);
    }
}
