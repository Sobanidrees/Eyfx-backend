import { MigrationInterface, QueryRunner } from "typeorm";

export class CreateInspectionDetailTable1702382614842 implements MigrationInterface {
    name = 'CreateInspectionDetailTable1702382614842'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TYPE "public"."inspection_detail_ratingunit_enum" AS ENUM('Accidented', 'NonAccidented', 'CompleteAndClean', 'IncompleteAndNotClean', 'CompleteButNotClean', 'IncompleteButClean', 'Leakage', 'NoLeakage', 'Ok', 'NotOk', 'Normal', 'Damage', 'Repaired', 'Present', 'NotPresent', 'Noise', 'NotNoise', 'Vibration', 'NoVibration', 'Working', 'NotWorking', 'Smooth', 'Rough', 'Play', 'BootDamage', 'NoDamageFound', 'Damaged', 'Polished', 'Scratched', 'Blurred', 'ShowingReflection', 'WorkingProperly', 'WorkingWithIssues', 'Perfect', 'Dirty', 'NotCheckedDueToMarketCover', 'Complete', 'Incomplete', 'Yes', 'No', 'ExcellentAirThrow', 'BadAirThrow', 'Excellent', 'NotGood', 'Error', 'NoError', 'Low', 'Full', 'Scratches', 'CrackedOrBroken', 'CleaningProperly', 'NotCleaningProperly', 'Broken')`);
        await queryRunner.query(`CREATE TABLE "inspection_detail" ("id" SERIAL NOT NULL, "image" character varying, "ratingPercentage" double precision, "ratingUnit" character varying, "parentId" integer, "createdAt" TIMESTAMP NOT NULL DEFAULT ('now'::text)::timestamp(6) with time zone, "updatedAt" TIMESTAMP NOT NULL DEFAULT ('now'::text)::timestamp(6) with time zone, "serviceId" integer, "coreServicesId" integer, "subServicesId" integer, "serviceRequestId" integer, CONSTRAINT "PK_af05d90f8c0eb7f3b37001614a5" PRIMARY KEY ("id"))`);
        await queryRunner.query(`ALTER TABLE "inspection_detail" ADD CONSTRAINT "FK_16cf08984e5c2ce4199f000bb43" FOREIGN KEY ("serviceId") REFERENCES "service"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "inspection_detail" ADD CONSTRAINT "FK_ce07b3dbbfca22e739ad8a3218c" FOREIGN KEY ("coreServicesId") REFERENCES "core_service"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "inspection_detail" ADD CONSTRAINT "FK_8de0b8a1b01b43b7aa5b3785c90" FOREIGN KEY ("subServicesId") REFERENCES "sub_services"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "inspection_detail" ADD CONSTRAINT "FK_7aa5f1f6e97a90d1f137eb7dfef" FOREIGN KEY ("serviceRequestId") REFERENCES "service_request"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "inspection_detail" DROP CONSTRAINT "FK_7aa5f1f6e97a90d1f137eb7dfef"`);
        await queryRunner.query(`ALTER TABLE "inspection_detail" DROP CONSTRAINT "FK_8de0b8a1b01b43b7aa5b3785c90"`);
        await queryRunner.query(`ALTER TABLE "inspection_detail" DROP CONSTRAINT "FK_ce07b3dbbfca22e739ad8a3218c"`);
        await queryRunner.query(`ALTER TABLE "inspection_detail" DROP CONSTRAINT "FK_16cf08984e5c2ce4199f000bb43"`);
        await queryRunner.query(`DROP TABLE "inspection_detail"`);
        await queryRunner.query(`DROP TYPE "public"."inspection_detail_ratingunit_enum"`);
    }
}
