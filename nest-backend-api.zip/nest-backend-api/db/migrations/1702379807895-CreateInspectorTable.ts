import { MigrationInterface, QueryRunner } from "typeorm";

export class CreateInspectorTable1702379807895 implements MigrationInterface {
    name = 'CreateInspectorTable1702379807895'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TABLE "inspector" ("id" SERIAL NOT NULL, "phoneNumber" character varying NOT NULL, "fullName" character varying NOT NULL, "emiratesId" character varying NOT NULL, "bio" character varying, "profileImage" character varying, "otpVerified" boolean, "createdAt" TIMESTAMP NOT NULL DEFAULT ('now'::text)::timestamp(6) with time zone, "updatedAt" TIMESTAMP NOT NULL DEFAULT ('now'::text)::timestamp(6) with time zone, CONSTRAINT "UQ_ab5e6b0f74f91f6d9ff2881cc34" UNIQUE ("phoneNumber"), CONSTRAINT "UQ_5f6febf320c8dd185731978d1a2" UNIQUE ("emiratesId"), CONSTRAINT "PK_089010107f03ba3889d9162b735" PRIMARY KEY ("id"))`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`DROP TABLE "inspector"`);
    }

}
