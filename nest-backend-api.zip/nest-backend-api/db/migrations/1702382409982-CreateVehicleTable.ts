import { MigrationInterface, QueryRunner } from "typeorm";

export class CreateVehicleTable1702382409982 implements MigrationInterface {
    name = 'CreateVehicleTable1702382409982'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TABLE "vehicle" ("id" SERIAL NOT NULL, "year" character varying NOT NULL, "make" character varying NOT NULL, "model" character varying NOT NULL, "engineCapacity" character varying, "mileage" character varying, "fuelType" character varying, "vin" character varying, "engineNo" character varying, "registrationNo" character varying, "transmissionType" character varying, "color" character varying, "image" character varying, "created_at" TIMESTAMP NOT NULL DEFAULT ('now'::text)::timestamp(6) with time zone, "updated_at" TIMESTAMP NOT NULL DEFAULT ('now'::text)::timestamp(6) with time zone, "consumerId" integer, CONSTRAINT "PK_187fa17ba39d367e5604b3d1ec9" PRIMARY KEY ("id"))`);
        await queryRunner.query(`ALTER TABLE "vehicle" ADD CONSTRAINT "FK_b1851891d413498a49c5b4603b5" FOREIGN KEY ("consumerId") REFERENCES "consumer"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "vehicle" DROP CONSTRAINT "FK_b1851891d413498a49c5b4603b5"`);
        await queryRunner.query(`DROP TABLE "vehicle"`);
    }
}
