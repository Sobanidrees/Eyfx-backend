import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { dataSourceOptions } from 'db/data-source';
import { ConsumerModule } from './consumer/consumer.module';
import { InspectorModule } from './inspector/inspector.module';
import { AdminModule } from './admin/admin.module';
import { APP_INTERCEPTOR } from '@nestjs/core';
import { Logger } from './utils/Logger/logger';
import { AuthModule } from './auth/auth.module';
import { TwilioModule } from './utils/twilio/twilio.module';
import { OtpModule } from './utils/otp/otp.module';
import { ServicesModule } from './services/services.module';
import { VehicleModule } from './vehicle/vehicle.module';
import { ServiceRequestModule } from './service_request/service_request.module';
import { ConfigModule } from '@nestjs/config';
import { InspectionDetailModule } from './inspection_detail/inspection_detail.module';
import { CoreServicesModule } from './core_services/core_services.module';
import { SubservicesModule } from './subservices/subservices.module';
import { PaymentModule } from './payment/payment.module';
import { InspectionReportModule } from './inspection_report/inspection_report.module';
import { GatewayModule } from './gateway/gateway.module';
import { ServiceMetaDataModule } from './service_meta_data/service_meta_data.module';
@Module({
  imports: [ConfigModule.forRoot({
    isGlobal: true,
    envFilePath: ['.env']
  }),TypeOrmModule.forRoot(dataSourceOptions), ConsumerModule, InspectorModule, AdminModule, AuthModule, TwilioModule, OtpModule, ServicesModule, CoreServicesModule, SubservicesModule, ServiceRequestModule, ServiceRequestModule, VehicleModule, InspectionDetailModule, PaymentModule, InspectionReportModule, GatewayModule, ServiceMetaDataModule],
  providers: [{ provide: APP_INTERCEPTOR, useClass: Logger }],
})
export class AppModule{}
