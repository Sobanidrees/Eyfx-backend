export enum InspectorStatus {
  Requested = 'Requested',
  Approved = 'Approved',
  Rejected = 'Rejected',
}
export enum CoreServiceStatus {
  Completed = 'Completed',
  InCompleted = 'InCompleted',
}
export enum Units {
  Accidented = 'Accidented',
  NonAccidented = 'Non Accidented',
  CompleteAndClean = 'Complete And Clean',
  IncompleteAndNotClean = 'Incomplete And Not Clean',
  CompleteButNotClean = 'Complete But Not Clean',
  IncompleteButClean = 'Incomplete But Clean',
  Leakage = 'Leakage',
  NoLeakage = 'No Leakage',
  Ok = 'Ok',
  NotOk = 'Not Ok',
  Normal = 'Normal',
  Damage = 'Damage',
  Repaired = 'Repaired',
  Present = 'Present',
  NotPresent = 'Not Present',
  Noise = 'Noise',
  NoNoise = 'No Noise',
  Vibration = 'Vibration',
  NoVibration = 'No Vibration',
  Working = 'Working',
  NotWorking = 'Not Working',
  Smooth = 'Smooth',
  Rough = 'Rough',
  Play = 'Play',
  BootDamage = 'Boot Damage',
  NoDamageFound = 'No Damage Found',
  Damaged = 'Damaged',
  Polished = 'Polished',
  Clear = 'Clear',
  Scratched = 'Scratched',
  Blurred = 'Blurred',
  ShowingReflection = 'Showing Reflection',
  WorkingProperly = 'Working Properly',
  WorkingWithIssues = 'Working With Issues',
  Perfect = 'Perfect',
  Dirty = 'Dirty',
  NotCheckedDueToMarketCover = 'Not Checked Due To Market Cover',
  Complete = 'Complete',
  Incomplete = 'Incomplete',
  Yes = 'Yes',
  No = 'No',
  ExcellentAirThrow = 'Excellent Air Throw',
  BadAirThrow = 'Bad Air Throw',
  Excellent = 'Excellent',
  NotGood = 'Not Good',
  Error = 'Error',
  NoError = 'No Error',
  Low = 'Low',
  Full = 'Full',
  Scratches = 'Scratches',
  CrackedOrBroken = 'Cracked Or Broken',
  CleaningProperly = 'Cleaning Properly',
  NotCleaningProperly = 'Not Cleaning Properly',
  Broken = 'Broken',
  NoDamage='No Damage'
}

export enum Status {
  Requested = 'Requested',
  Pending = 'Pending',
  InProgress = 'InProgress',
  Completed = 'Completed',
  ReportShared = 'ReportShared',
}

export enum packageType {
  Basic = 'Basic',
  Premium = 'Premium',
}

export const Price = {
  Basic: process.env.BASIC_PRODUCT,
  Premium: process.env.PREMIUM_PRODUCT,
};

export const InspectionServices = {
  'Radiator Core Support': {
    ratingUnit: {
      'Accidented': 0,
      'Non Accidented': 1,
    },
  },
  'Right Strut Tower Apron': {
    ratingUnit: {
      'Accidented': 0,
      'Non Accidented': 1,
    },
  },
  'Left Strut Tower Apron': {
    ratingUnit: {
      'Accidented': 0,
      'Non Accidented': 1,
    },
  },
  'Right Front Rail': {
    ratingUnit: {
      'Accidented': 0,
      'Non Accidented': 1,
    },
  },
  'Left Front Rail': {
    ratingUnit: {
      'Accidented': 0,
      'Non Accidented': 1,
    },
  },
  'Cowl Panel Firewall': {
    ratingUnit: {
      'Accidented': 0,
      'Non Accidented': 1,
    },
  },
  'Right A Pillar': {
    ratingUnit: {
      'Accidented': 0,
      'Non Accidented': 1,
    },
  },
  'Left A Pillar': {
    ratingUnit: {
      'Accidented': 0,
      'Non Accidented': 1,
    },
  },
  'Right B Pillar': {
    ratingUnit: {
      'Accidented': 0,
      'Non Accidented': 1,
    },
  },
  'Left B Pillar': {
    ratingUnit: {
      'Accidented': 0,
      'Non Accidented': 1,
    },
  },
  'Right C Pillar': {
    ratingUnit: {
      'Accidented': 0,
      'Non Accidented': 1,
    },
  },
  'Left C Pillar': {
    ratingUnit: {
      'Accidented': 0,
      'Non Accidented': 1,
    },
  },
  'Boot Floor': {
    ratingUnit: {
      'Accidented': 0,
      'Non Accidented': 1,
    },
  },
  'Boot Lock Pillar': {
    ratingUnit: {
      'Accidented': 0,
      'Non Accidented': 1,
    },
  },
  'Front Subframe': {
    ratingUnit: {
      'Accidented': 0,
      'Non Accidented': 1,
    },
  },
  'Rear Subframe': {
    ratingUnit: {
      'Accidented': 0,
      'Non Accidented': 1,
    },
  },
  'Engine Oil Level': {
    ratingUnit: {
      'Complete And Clean': 2,
      'Incomplete And Not Clean': 0,
      'Complete But Not Clean': 1,
      'Incomplete But Clean': 1,
    },
  },
  'Engine Oil Leakage': {
    ratingUnit: {
      'No Leakage': 2,
      'Leakage': 0,
    },
  },
  'Transmission Oil Leakage': {
    ratingUnit: {
      'No Leakage': 2,
      'Leakage': 0,
    },
  },
  'Coolant Leakage': {
    ratingUnit: {
      'No Leakage': 2,
      'Leakage': 0,
    },
  },
  'Brake Oil Leakage': {
    ratingUnit: {
      'No Leakage': 2,
      'Leakage': 0,
    },
  },
  'Exhaust Sound': {
    ratingUnit: {
      'Ok': 2,
      'Not Ok': 0,
    },
  },
  'Belts': {
    ratingUnit: {
      'Ok': 2,
      'Not Ok': 0,
    },
  },
  'Wires': {
    ratingUnit: {
      'Normal': 1,
      'Damage': 0,
      'Repaired': 0,
    },
  },
  'Engine Blow': {
    ratingUnit: {
      'Present': 2,
      'Not Present': 0,
    },
  },
  'Engine Noise': {
    ratingUnit: {
      'No Noise': 2,
      'Noise': 0,
    },
  },
  'Engine Vibration': {
    ratingUnit: {
      'No Vibration': 2,
      'Vibration': 0,
    },
  },
  'Engine Mounts': {
    ratingUnit: {
      'Ok': 2,
      'Not Ok': 0,
    },
  },
  'Pulleys (Adjuster)': {
    ratingUnit: {
      'Ok': 2,
      'Not Ok': 0,
    },
  },
  'Hoses': {
    ratingUnit: {
      'Normal': 1,
      'Damage': 0,
      'Repaired': 0,
    },
  },
  'Radiator': {
    ratingUnit: {
      'Ok': 2,
      'Not Ok': 0,
    },
  },
  'Suction Fan': {
    ratingUnit: {
      'Working': 2,
      'Not Working': 0,
    },
  },
  'Starter Operation': {
    ratingUnit: {
      'Ok': 2,
      'Not Ok': 0,
    },
  },
  'Front Right Disc': {
    ratingUnit: {
      'Smooth': 2,
      'Rough': 0,
    },
  },
  'Front Left Disc': {
    ratingUnit: {
      'Smooth': 2,
      'Rough': 0,
    },
  },
  'Parking / Hand Brake': {
    ratingUnit: {
      'Ok': 1,
      'Not Ok': 0,
    },
  },
  'Steering Wheel Play': {
    ratingUnit: {
      'Normal': 2,
      'Play': 0,
    },
  },
  'Right Ball Joint': {
    ratingUnit: {
      'Ok': 2,
      'Boot Damage': 0,
      'Play': 0,
    },
  },
  'Left Ball Joint': {
    ratingUnit: {
      'Ok': 2,
      'Boot Damage': 0,
      'Play': 0,
    },
  },
  'Right Z Links': {
    ratingUnit: {
      'Ok': 1,
      'Damage': 0,
    },
  },
  'Left Z Links': {
    ratingUnit: {
      'Ok': 1,
      'Damage': 0,
    },
  },
  'Right Tie Rod End': {
    ratingUnit: {
      'Ok': 2,
      'Boot Damage': 0,
      'Play': 0,
    },
  },
  'Left Tie Rod End': {
    ratingUnit: {
      'Ok': 2,
      'Boot Damage': 0,
      Play: 0,
    },
  },
  'Front Right Boots': {
    ratingUnit: {
      'Ok': 1,
      'Damaged': 0,
    },
  },
  'Front Left Boots': {
    ratingUnit: {
      'Ok': 1,
      'Damaged': 0,
    },
  },
  'Front Right Bushes': {
    ratingUnit: {
      'No Damage': 1,
      'Damaged': 0,
    },
  },
  'Front Left Bushes': {
    ratingUnit: {
      'No Damage': 1,
      'Damaged': 0,
    },
  },
  'Front Right Shock': {
    ratingUnit: {
      'Ok': 2,
      'Damaged': 0,
    },
  },
  'Front Left Shock': {
    ratingUnit: {
      'Ok': 2,
      'Damaged': 0,
    },
  },
  'Rear Right Bushes': {
    ratingUnit: {
      'No Damage': 1,
      'Damaged': 0,
    },
  },
  'Rear Left Bushes': {
    ratingUnit: {
      'No Damage': 1,
      'Damaged': 0,
    },
  },
  'Rear Left Shock': {
    ratingUnit: {
      'Ok': 2,
      'Damaged': 0,
    },
  },
  'Rear Right Shock': {
    ratingUnit: {
      'Ok': 2,
      'Damaged': 0,
    },
  },
  'Steering Wheel Condition': {
    ratingUnit: {
      'Polished': 1,
      'Scratched': 0,
    },
  },
  'Horn': {
    ratingUnit: {
      'Working': 1,
      'Not Working': 0,
    },
  },
  'Lights Lever / Switch': {
    ratingUnit: {
      'Working': 1,
      'Not Working': 0,
    },
  },
  'Wiper / Washer Lever': {
    ratingUnit: {
      'Working': 1,
      'Not Working': 0,
    },
  },
  'Right Side Mirror': {
    ratingUnit: {
      'Working': 1,
      'Not Working': 0,
    },
  },
  'Left Side Mirror': {
    ratingUnit: {
      'Working': 1,
      'Not Working': 0,
    },
  },
  'Rear View Mirror Dimmer': {
    ratingUnit: {
      'Clear': 2,
      'Blurred': 1,
      'Showing Reflection': 0,
    },
  },
  'Right Seat Adjuster Recliner': {
    ratingUnit: {
      'Working': 1,
      'Not Working': 0,
    },
  },
  'Left Seat Adjuster Recliner': {
    ratingUnit: {
      'Working': 1,
      'Not Working': 0,
    },
  },
  'Right Seat Adjuster Lear Track': {
    ratingUnit: {
      'Working': 1,
      'Not Working': 0,
    },
  },
  'Left Seat Adjuster Lear Track': {
    ratingUnit: {
      'Working': 1,
      'Not Working': 0,
    },
  },
  'Right Seat Belt': {
    ratingUnit: {
      'Working': 2,
      'Not Working': 0,
    },
  },
  'Left Seat Belt': {
    ratingUnit: {
      'Working': 2,
      'Not Working': 0,
    },
  },
  'Rear Seat Belts': {
    ratingUnit: {
      'Working': 1,
      'Not Working': 0,
    },
  },
  'Glove Box': {
    ratingUnit: {
      'Working': 1,
      'Not Working': 0,
    },
  },
  'Front Right Power Window/Manual Lever': {
    ratingUnit: {
      'Working Properly': 2,
      'Working With Issues': 1,
      'Not Working': 0,
    },
  },
  'Front Left Power Window/Manual Lever': {
    ratingUnit: {
      'Working Properly': 2,
      'Working With Issues': 1,
      'Not Working': 0,
    },
  },
  'Rear Right Power Window/Manual Lever': {
    ratingUnit: {
      'Working Properly': 2,
      'Working With Issues': 1,
      'Not Working': 0,
    },
  },
  'Rear Left Power Window/Manual Lever': {
    ratingUnit: {
      'Working Properly': 2,
      'Working With Issues': 1,
      'Not Working': 0,
    },
  },
  'Window Safety Lock': {
    ratingUnit: {
      'Working': 1,
      'Not Working': 0,
    },
  },
  'Interior Lightings': {
    ratingUnit: {
      'Working': 1,
      'Not Working': 0,
    },
  },
  'Dash Controls - A/C': {
    ratingUnit: {
      'Working': 1,
      'Not Working': 0,
    },
  },
  'Dash Controls - De-Fog': {
    ratingUnit: {
      'Working': 1,
      'Not Working': 0,
    },
  },
  'Dash Controls - Hazard Lights': {
    ratingUnit: {
      'Working': 1,
      'Not Working': 0,
    },
  },
  'Dash Controls - Others': {
    ratingUnit: {
      'Working': 1,
      'Not Working': 0,
    },
  },
  'Audio / Video': {
    ratingUnit: {
      'Working Properly': 1,
      'Working With Issues': 0,
      'Not Working': 0,
    },
  },
  'Trunk Release Lever / Button': {
    ratingUnit: {
      'Working': 1,
      'Not Working': 0,
    },
  },
  'Fuel Cap Release Lever / Button': {
    ratingUnit: {
      'Working': 1,
      'Not Working': 0,
    },
  },
  'Bonnet Release Lever / Button': {
    ratingUnit: {
      'Working': 1,
      'Not Working': 0,
    },
  },
  'Roof Poshish': {
    ratingUnit: {
      'Perfect': 2,
      'Dirty': 1,
      'Damaged': 0,
    },
  },
  'Floor Mat': {
    ratingUnit: {
      'Perfect': 1,
      'Dirty': 0,
      'Damaged': 0,
    },
  },
  'Front Right Seat Poshish': {
    ratingUnit: {
      'Perfect': 1,
      'Dirty': 0,
      'Damaged': 0,
      'Not Checked Due To Market Cover': 0,
    },
  },
  'Front Left Seat Poshish': {
    ratingUnit: {
      'Perfect': 1,
      'Dirty': 0,
      'Damaged': 0,
      'Not Checked Due To Market Cover': 0,
    },
  },
  'Rear Seat Poshish': {
    ratingUnit: {
      'Perfect': 1,
      'Dirty': 0,
      'Damaged': 0,
      'Not Checked Due To Market Cover': 0,
    },
  },
  'Dashboard Condition': {
    ratingUnit: {
      'Perfect': 1,
      'Dirty': 0,
      'Damaged': 0,
    },
  },
  'Spare Tire': {
    ratingUnit: {
      'Present': 2,
      'Not Present': 0,
    },
  },
  'Tools': {
    ratingUnit: {
      'Complete': 1,
      'Incomplete': 0,
    },
  },
  'Jack': {
    ratingUnit: {
      'Present': 1,
      'Not Present': 0,
    },
  },
  'AC Fitted': {
    ratingUnit: {
      'Yes': 2,
      'No': 0,
    },
  },
  'AC Operational': {
    ratingUnit: {
      'Yes': 2,
      'No': 0,
    },
  },
  'Blower': {
    ratingUnit: {
      'Excellent Air Throw': 1,
      'Bad Air Throw': 0,
    },
  },
  'Cooling': {
    ratingUnit: {
      'Excellent': 1,
      'Not Good': 0,
    },
  },
  'Heating': {
    ratingUnit: {
      'Excellent': 1,
      'Not Good': 0,
    },
  },
  'Computer Check up / Malfunction Check': {
    ratingUnit: {
      'Error': 0,
      'No Error': 2,
    },
  },
  'Battery Warning Light': {
    ratingUnit: {
      'Present': 1,
      'Not Present': 0,
    },
  },
  'Oil Pressure Low Warning Light': {
    ratingUnit: {
      'Present': 1,
      'Not Present': 0,
    },
  },
  'Temperature Warning Light / Gauge': {
    ratingUnit: {
      'Present': 1,
      'Not Present': 0,
    },
  },
  'Power Steering Warning Light': {
    ratingUnit: {
      'Present': 1,
      'Not Present': 0,
    },
  },
  'Voltage': {
    ratingUnit: {
      'Low': 0,
      'Normal': 1,
    },
  },
  'Terminals Condition': {
    ratingUnit: {
      'Ok': 1,
      'Not Ok': 0,
    },
  },
  'Charging': {
    ratingUnit: {
      'Ok': 2,
      'Not Ok': 0,
    },
  },
  'Alternator Operation': {
    ratingUnit: {
      'Ok': 1,
      'Not Ok': 0,
    },
  },
  'Gauges': {
    ratingUnit: {
      'Working': 1,
      'Not Working': 0,
    },
  },
  'Trunk Lock': {
    ratingUnit: {
      'Ok': 1,
      'Not Ok': 0,
    },
  },
  'Front Windshield Condition': {
    ratingUnit: {
      'Perfect': 2,
      'Scratches': 1,
      'Cracked Or Broken': 0,
    },
  },
  'Rear Windshield Condition': {
    ratingUnit: {
      'Perfect': 2,
      'Scratches': 1,
      'Cracked Or Broken': 0,
    },
  },
  'Front Right Door Window': {
    ratingUnit: {
      'Perfect': 2,
      'Scratches': 1,
      'Cracked Or Broken': 0,
    },
  },
  'Front Left Door Window': {
    ratingUnit: {
      'Perfect': 2,
      'Scratches': 1,
      'Cracked Or Broken': 0,
    },
  },
  'Rear Right Door Window': {
    ratingUnit: {
      'Perfect': 1,
      'Scratches': 1,
      'Cracked Or Broken': 0,
    },
  },
  'Rear Left Door Window': {
    ratingUnit: {
      'Perfect': 1,
      'Scratches': 1,
      'Cracked Or Broken': 0,
    },
  },
  'Windscreen Wiper': {
    ratingUnit: {
      'Cleaning Properly': 1,
      'Not Cleaning Properly': 0,
    },
  },
  'Right Headlight (Working)': {
    ratingUnit: {
      'Working': 2,
      'Not Working': 0,
    },
  },
  'Right Headlight (Condition)': {
    ratingUnit: {
      'Perfect': 2,
      'Repaired': 1,
      'Cracked Or Broken': 0,
    },
  },
  'Left Headlight (Condition)': {
    ratingUnit: {
      'Perfect': 2,
      'Repaired': 1,
      'Cracked Or Broken': 0,
    },
  },
  'Left Headlight (Working)': {
    ratingUnit: {
      'Working': 2,
      'Not Working': 0,
    },
  },
  'Right Taillight (Working)': {
    ratingUnit: {
      'Working': 1,
      'Not Working': 0,
    },
  },
  'Left Taillight (Working)': {
    ratingUnit: {
      'Working': 1,
      'Not Working': 0,
    },
  },
  'Right Taillight (Condition)': {
    ratingUnit: {
      'Perfect': 2,
      'Repaired': 1,
      'Cracked Or Broken': 0,
    },
  },
  'Left Taillight (Condition)': {
    ratingUnit: {
      'Perfect': 2,
      'Repaired': 1,
      'Cracked Or Broken': 0,
    },
  },
  'Front Right Tyre': {
    ratingUnit: {
      'Normal': 2,
      'Repaired': 1,
      'Damaged': 0,
    },
  },
  'Front Left Tyre': {
    ratingUnit: {
      'Normal': 2,
      'Repaired': 1,
      'Damaged': 0,
    },
  },
  'Rear Right Tyre': {
    ratingUnit: {
      'Normal': 2,
      'Repaired': 1,
      'Damaged': 0,
    },
  },
  'Rear Left Tyre': {
    ratingUnit: {
      'Normal': 2,
      'Repaired': 1,
      'Damaged': 0,
    },
  },
  'Rims': {
    ratingUnit: {
      'Normal': 2,
      'Repaired': 1,
      'Damaged': 0,
    },
  },
  'Wheel Caps': {
    ratingUnit: {
      'Normal': 1,
      'Broken': 0,
      'Not Present': 0,
    },
  },
};
