import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsString } from 'class-validator';
import { IsPhoneNumber } from 'src/utils/decorator/phone-number.decorator';

export class ReSendOtpDto {
  @ApiProperty({
    example: '+971123456789',
    description: 'The phone number of the account',
    format: 'string',
  })
  @IsString()
  @IsPhoneNumber()
  @IsNotEmpty()
  phoneNumber: string;
}
