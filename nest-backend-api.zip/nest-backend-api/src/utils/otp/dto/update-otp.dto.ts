import { ApiProperty, PartialType } from '@nestjs/swagger';
import { CreateOtpDto } from './create-otp.dto';
import { IsNotEmpty, IsString, Length } from 'class-validator';

export class UpdateOtpDto extends PartialType(CreateOtpDto) {
  @ApiProperty({
    example: '+971123456789',
    description: 'The is your otp',
    format: 'string',
  })
  @IsString()
  @IsNotEmpty()
  @Length(4, 4, { message: 'OTP must be exactly 4 characters long' })
  otp: string;
}
