import { Body, HttpException, HttpStatus, Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Otp } from './entities/otp.entity';
import { Repository } from 'typeorm';
import { CreateOtpDto } from './dto/create-otp.dto';
import { VerifyOtpDto } from 'src/utils/otp/dto/verify-otp-dto';
import { UpdateOtpDto } from './dto/update-otp.dto';
import { TwilioService } from '../twilio/twilio.service';

@Injectable()
export class OtpService {
  constructor(@InjectRepository(Otp) private otpRepository: Repository<Otp>, private readonly twilioService: TwilioService) {}
  async create(body: CreateOtpDto): Promise<Otp> {
    return await this.otpRepository.save(this.otpRepository.create(body)).catch((err: any) => {
      throw new HttpException(
        {
          message: `${err}`,
        },
        HttpStatus.CONFLICT,
      );
    });
  }

  async findWithPhoneNumberAndOtp(@Body() body: VerifyOtpDto): Promise<Otp> {
    return this.otpRepository.findOne({ where: { phoneNumber: body.phoneNumber, otp: body.otp } });
  }
  async findWithPhoneNumber(phoneNumber: string): Promise<Otp> {
    return this.otpRepository.findOne({ where: { phoneNumber } });
  }

  async update(id: number, body: UpdateOtpDto): Promise<Otp> {
    try {
      const otp = await this.findOne(id);
      this.otpRepository.merge(otp, body);
      return this.otpRepository.save(otp);
    } catch (e) {
      throw new HttpException(e.message, e.statusCode);
    }
  }

  async findOne(id: number): Promise<Otp> {
    try {
      const otp = await this.otpRepository.findOne({ where: { id } });
      if (!otp) throw new HttpException({ message: `${`Otp not found with id ${id}`}` }, HttpStatus.NOT_FOUND);
      return otp;
    } catch (e) {
      throw new HttpException(e.message, e.statusCode);
    }
  }
  async remove(id: number): Promise<Object> {
    try {
      const otp = await this.findOne(id);
      if (!otp) throw new NotFoundException();
      return this.otpRepository.delete(id);
    } catch (e) {
      throw new HttpException(e.message, e.statusCode);
    }
  }

  async generateAndSendOTP(phoneNumber: string): Promise<string> {
    try {
      let otp = '1234';
      if (process.env.NODE_ENV === 'production'||process.env.NODE_ENV === 'staging' ) {
        const currentDate = new Date();
        const day = currentDate.getDate();
        const month = currentDate.getMonth() + 1;
        const year = currentDate.getFullYear() % 100;
        const calculatedValue = day + month + year;
        const randomPart = Math.floor(Math.random() * 9000) + 1000;
        otp = (calculatedValue + randomPart).toString().slice(-4);
        await this.twilioService.sendOtp(phoneNumber, otp);
      }
      const otpObject = await this.findWithPhoneNumber(phoneNumber);
      if (!otpObject) {
        await this.create({ phoneNumber, otp: otp.toString() });
      } else {
        await this.update(otpObject.id, { otp: otp });
      }
      return otp;
    } catch (e) {
      throw new HttpException(e.message, e.statusCode);
    }
  }
}
