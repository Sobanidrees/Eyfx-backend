import { Module } from '@nestjs/common';
import { OtpService } from './otp.service';
import { Otp } from './entities/otp.entity';
import { TypeOrmModule } from '@nestjs/typeorm';
import { TwilioModule } from '../twilio/twilio.module';

@Module({
  imports: [TypeOrmModule.forFeature([Otp]), TwilioModule],
  providers: [OtpService],
  exports: [OtpService],
})
export class OtpModule {}
