import { IsNotEmpty, IsString, Length } from 'class-validator';
import { IsPhoneNumber } from 'src/utils/decorator/phone-number.decorator';
import { Column, CreateDateColumn, Entity, PrimaryGeneratedColumn, UpdateDateColumn } from 'typeorm';
@Entity()
export class Otp {
  @PrimaryGeneratedColumn()
  id: number;

  @IsNotEmpty()
  @IsString()
  @Column({ unique: true })
  @IsPhoneNumber()
  phoneNumber: string;

  @IsString()
  @Column()
  @Length(4, 4, { message: 'OTP must be exactly 4 characters long' })
  otp: string;

  @CreateDateColumn({
    type: 'timestamp',
    default: () => 'CURRENT_TIMESTAMP(6)',
  })
  public createdAt: Date;

  @UpdateDateColumn({
    type: 'timestamp',
    default: () => 'CURRENT_TIMESTAMP(6)',
    onUpdate: 'CURRENT_TIMESTAMP(6)',
  })
  public updatedAt: Date;
}
