import { registerDecorator, ValidationOptions, ValidationArguments } from 'class-validator';

const EMIRATES_ID_REGEX = /^\d{3}-\d{4}-\d{7}-\d{1}$/; // Regex for the format xxx-xxxx-xxxxxxx-x

export function IsEmiratesId(validationOptions?: ValidationOptions) {
  return function (object: Object, propertyName: string) {
    registerDecorator({
      name: 'isEmiratesId',
      target: object.constructor,
      propertyName: propertyName,
      options: validationOptions,
      validator: {
        validate(value: any, args: ValidationArguments) {
          if (!value) {
            return false;
          }
          return EMIRATES_ID_REGEX.test(value);
        },
        defaultMessage(args: ValidationArguments) {
          return `${args.property} must be a valid Emirates ID in the specified format: xxx-xxxx-xxxxxxx-x`;
        },
      },
    });
  };
}
