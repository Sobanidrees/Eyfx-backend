import { ValidatorConstraint, ValidatorConstraintInterface, ValidationArguments, ValidationOptions, registerDecorator } from 'class-validator';

@ValidatorConstraint({ name: 'customFullName', async: false })
export class FullNameValidator implements ValidatorConstraintInterface {
  validate(value: string, args: ValidationArguments) {
    // Allow empty values
    if (!value) {
      return true;
    }

    // Return true if the value contains only alphabetic characters and spaces
    return /^[A-Za-z\s]+$/.test(value);
  }

  defaultMessage(args: ValidationArguments) {
    return 'Full name should contain only alphabetic characters and spaces';
  }
}

// Create a decorator to use the custom validator
export function IsFullName(validationOptions?: ValidationOptions) {
  return function (object: Object, propertyName: string) {
    registerDecorator({
      name: 'isCustomFullName',
      target: object.constructor,
      propertyName: propertyName,
      options: validationOptions,
      validator: FullNameValidator,
    });
  };
}
