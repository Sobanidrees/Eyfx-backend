import {
  registerDecorator,
  ValidationOptions,
  ValidationArguments,
} from 'class-validator';

const DATE_FORMAT_REGEX = /^(0[1-9]|[12][0-9]|3[01])\/(0[1-9]|1[0-2])\/\d{4}$/;

export function IsCustomDate(validationOptions?: ValidationOptions) {
  return function (object: Object, propertyName: string) {
    registerDecorator({
      name: 'isCustomDateFormat',
      target: object.constructor,
      propertyName: propertyName,
      options: validationOptions,
      validator: {
        validate(value: any, args: ValidationArguments) {
          if (!value) {
            return false;
          }
          if (!DATE_FORMAT_REGEX.test(value)) {
            return false; 
          }
          const year = parseInt(value.split('/')[2], 10);
          const currentYear = new Date().getFullYear();
          const minYear = currentYear - 100;
          const maxYear = currentYear + 10;

          return year >= minYear && year <= maxYear;
        },
        defaultMessage(args: ValidationArguments) {
          return `${args.property} must be in DD/MM/YYYY format with a valid day (01-31), month (01-12), and a reasonable year.`;
        },
      },
    });
  };
}
