import { BadRequestException, createParamDecorator, ExecutionContext } from '@nestjs/common';
import { Request } from 'express';
import { Inspector } from 'src/inspector/entities/inspector.entity';
import { Consumer } from 'src/consumer/entities/consumer.entity';
import { Admin } from 'src/admin/entities/admin.entity';

export const CurrentUser = createParamDecorator((data: unknown, context: ExecutionContext): Inspector | Consumer | Admin => {
  try {
    const request = context.switchToHttp().getRequest<Request>();
    return request.user as Inspector | Consumer | Admin;
  } catch (e) {
    throw new BadRequestException(e.message);
  }
});
