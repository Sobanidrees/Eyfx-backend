import { registerDecorator, ValidationOptions, ValidationArguments, ValidatorConstraint, ValidatorConstraintInterface } from 'class-validator';

const TIME_FORMAT_REGEX = /^(0?[1-9]|1[0-2]):[0-5][0-9]\s?[APap][Mm]$/;

@ValidatorConstraint({ name: 'customTimeFormat', async: false })
class CustomTimeFormatValidator implements ValidatorConstraintInterface {
  validate(value: string, args: ValidationArguments) {
    return TIME_FORMAT_REGEX.test(value);
  }

  defaultMessage(args: ValidationArguments) {
    return `Invalid time format. It should be in HH:mm AM/PM format (e.g., 12:30 AM).`;
  }
}

export function IsCustomTime(validationOptions?: ValidationOptions) {
  return function (object: Object, propertyName: string) {
    registerDecorator({
      name: 'isCustomTimeFormat',
      target: object.constructor,
      propertyName: propertyName,
      options: validationOptions,
      validator: CustomTimeFormatValidator,
    });
  };
}
