import { registerDecorator, ValidationOptions, ValidationArguments } from 'class-validator';

const UAE_PHONE_NUMBER_REGEX = /^\+971\d{9}$/;

export function IsPhoneNumber(validationOptions?: ValidationOptions) {
  return function (object: Object, propertyName: string) {
    registerDecorator({
      name: 'isUAEPhoneNumber',
      target: object.constructor,
      propertyName: propertyName,
      options: validationOptions,
      validator: {
        validate(value: any, args: ValidationArguments) {
          if (!value) {
            return false;
          }
          return UAE_PHONE_NUMBER_REGEX.test(value);
        },
        defaultMessage(args: ValidationArguments) {
          return `${args.property} must be a valid UAE phone number in the specified format (+971XXXXXXXXX).`;
        },
      },
    });
  };
}
