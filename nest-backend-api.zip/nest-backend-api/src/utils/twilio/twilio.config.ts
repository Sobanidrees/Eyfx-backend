// twilio.config.ts
export const twilioConfig = {
  accountSid: process.env.ACCOUNT_SID,
  authToken: process.env.AUTH_TOKEN,
  twilioPhoneNumber: process.env.TWILIO_PHONE_NUMBER, // Twilio phone number from which OTP will be sent
};
