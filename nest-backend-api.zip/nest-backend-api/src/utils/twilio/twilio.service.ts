// twilio.service.ts
import { Injectable } from '@nestjs/common';
import { twilioConfig } from './twilio.config';

const twilio = require('twilio');

@Injectable()
export class TwilioService {
  private readonly twilioClient;

  constructor() {
    this.twilioClient = twilio(twilioConfig.accountSid, twilioConfig.authToken);
  }

  async sendOtp(phoneNumber: string, otp: string): Promise<void> {
    try {
      await this.twilioClient.messages.create({
        body: `Your OTP is: ${otp}`,
        from: twilioConfig.twilioPhoneNumber,
        to: phoneNumber,
      });
    } catch (error) {
      throw new Error('Failed to send OTP. Please try again later.');
    }
  }
}
