import { Module } from '@nestjs/common';
import { InspectionReportController } from './inspection_report.controller';
import { InspectionDetailModule } from 'src/inspection_detail/inspection_detail.module';

@Module({
  imports: [InspectionDetailModule],
  controllers: [InspectionReportController],
})
export class InspectionReportModule {}
