import { Controller, Param, Get, UseGuards } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { InspectionDetailService } from 'src/inspection_detail/inspection_detail.service';

@ApiTags('Inspection Report')
@Controller('inspection-report')
export class InspectionReportController {
  constructor(private readonly inspectionDetailService: InspectionDetailService) {}

  @ApiOperation({
    description: 'A successful hit can return inspection report',
    summary: 'Get Inspection Report',
  })
  // @ApiBearerAuth(process.env.X_ACCESS_TOKEN)
  // @UseGuards(AuthGuard('jwt'))
  @Get(':id')
  create(@Param('id') id: string) {
    return this.inspectionDetailService.ratingCalculations(+id);
  }
}
