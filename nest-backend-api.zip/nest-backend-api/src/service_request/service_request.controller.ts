import { Controller, Get, Post, Body, Param, Delete, BadRequestException, UseGuards, Patch } from '@nestjs/common';
import { ServiceRequestService } from './service_request.service';
import { CreateServiceRequestDto } from './dto/create-service_request.dto';
import { ApiBearerAuth, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { ServiceRequest } from './entities/service_request.entity';
import { AuthGuard } from '@nestjs/passport';
import { UpdateServiceRequestDto } from './dto/update-service_request.dto';
import { GatewayService } from 'src/gateway/gateway.service';

@ApiTags('Service Request')
@Controller('service-request')
export class ServiceRequestController {
  constructor(private readonly serviceRequestService: ServiceRequestService, private readonly socketGateway: GatewayService) {}

  @ApiOperation({
    description: 'A successful hit can create service request',
    summary: 'Create Service Request',
  })
  @ApiResponse({ status: 201, description: 'Successfully Create Service Request.', type: ServiceRequest })
  @ApiBearerAuth(process.env.X_ACCESS_TOKEN)
  @UseGuards(AuthGuard('jwt'))
  @Post()
  async create(@Body() body: CreateServiceRequestDto): Promise<ServiceRequest> {
    try {
      const createdServiceRequest = await this.serviceRequestService.create(body);
      this.socketGateway.notifyAdminsNewServiceRequest(createdServiceRequest);
      return createdServiceRequest;
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  @ApiOperation({
    description: 'A successful hit can create service request',
    summary: 'Create Service Request',
  })
  @ApiResponse({ status: 201, description: 'Successfully Create Service Request.', type: ServiceRequest })
  @Post('word-press')
  async createSrFromWordPress(@Body() body: CreateServiceRequestDto): Promise<ServiceRequest> {
    try {
      const createdServiceRequest = await this.serviceRequestService.create(body);
      this.socketGateway.notifyAdminsNewServiceRequest(createdServiceRequest);
      return createdServiceRequest;
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }
  @ApiOperation({
    description: 'A successful hit can return all Service Requests',
    summary: 'Get All Service Requests',
  })
  @ApiResponse({ status: 200, description: 'Successfully retrieved All Admin.', type: [ServiceRequest] })
  @ApiBearerAuth(process.env.X_ACCESS_TOKEN)
  @UseGuards(AuthGuard('jwt'))
  @Get()
  async findAll(): Promise<ServiceRequest[]> {
    try {
      return this.serviceRequestService.findAll();
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  @ApiOperation({
    description: 'A successful hit can return service request against id',
    summary: 'Get service request Against Id',
  })
  @ApiResponse({ status: 200, description: 'Successfully retrieved service request against id .', type: ServiceRequest })
  // @ApiBearerAuth(process.env.X_ACCESS_TOKEN)
  // @UseGuards(AuthGuard('jwt'))
  @Get(':id')
  async findOne(@Param('id') id: string): Promise<ServiceRequest> {
    try {
      return this.serviceRequestService.findOne(+id);
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  @ApiOperation({
    description: 'A successful hit can return Service request against id',
    summary: 'Update Service Request Against Id',
  })
  @ApiResponse({ status: 200, description: 'Successfully update service request against id.', type: ServiceRequest })
  @ApiBearerAuth(process.env.X_ACCESS_TOKEN)
  @UseGuards(AuthGuard('jwt'))
  @Patch(':id')
  async update(@Param('id') id: number, @Body() body: UpdateServiceRequestDto): Promise<ServiceRequest> {
    try {
      const Sr = await this.serviceRequestService.update(id, body);
      this.socketGateway.updateServiceRequestStatus(Sr);
      return Sr;
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  @ApiOperation({
    description: 'A successful hit can delete service request against id',
    summary: 'Delete service request Against Id',
  })
  @Delete(':id')
  @ApiBearerAuth(process.env.X_ACCESS_TOKEN)
  @UseGuards(AuthGuard('jwt'))
  async remove(@Param('id') id: string) {
    try {
      return this.serviceRequestService.remove(+id);
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }
}
