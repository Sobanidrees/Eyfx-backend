import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsString } from 'class-validator';
import { packageType } from 'src/utils/constant/constants';
import { IsCustomDate } from 'src/utils/decorator/date.decorator';
import { IsPhoneNumber } from 'src/utils/decorator/phone-number.decorator';
import { IsCustomTime } from 'src/utils/decorator/time.decorator';

export class CreateServiceRequestDto {
  @ApiProperty({ example: '+971123456789' })
  @IsString()
  @IsNotEmpty()
  @IsPhoneNumber()
  phoneNumber: string;

  @ApiProperty({ example: 'Soban' })
  @IsString()
  @IsNotEmpty()
  fullName: string;

  @ApiProperty({ example: 'Inspection' })
  @IsString()
  @IsNotEmpty()
  service: string;

  @ApiProperty({ example: 'DD/MM/YYYY' })
  @IsNotEmpty()
  @IsCustomDate()
  date: string;

  @ApiProperty({ example: '12:30AM' })
  @IsNotEmpty()
  @IsString()
  @IsCustomTime()
  time: string;

  @ApiProperty({ example: '2012' })
  @IsString()
  @IsNotEmpty()
  year: string;

  @ApiProperty({ example: 'Audi' })
  @IsString()
  @IsNotEmpty()
  make: string;

  @ApiProperty({ example: 'A8' })
  @IsString()
  @IsNotEmpty()
  model: string;

  @ApiProperty({ example: 'House # 5, Street # 5, Younispurah, Lahore' })
  @IsNotEmpty()
  @IsString()
  address: string;

  @ApiProperty({ example: 'Basic' })
  @IsNotEmpty()
  packageType: packageType;
}
