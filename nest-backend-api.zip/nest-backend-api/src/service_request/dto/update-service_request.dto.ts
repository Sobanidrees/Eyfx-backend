import { ApiProperty } from '@nestjs/swagger';
import { Status } from 'src/utils/constant/constants';

export class UpdateServiceRequestDto {
  @ApiProperty({ example: 'Completed' })
  status: Status;
}
