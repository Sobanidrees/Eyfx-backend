import { Module } from '@nestjs/common';
import { ServiceRequestService } from './service_request.service';
import { ServiceRequestController } from './service_request.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ServiceRequest } from './entities/service_request.entity';
import { ConsumerModule } from 'src/consumer/consumer.module';
import { VehicleModule } from 'src/vehicle/vehicle.module';
import { Vehicle } from 'src/vehicle/entities/vehicle.entity';
import { ServicesModule } from 'src/services/services.module';
import { GatewayModule } from 'src/gateway/gateway.module';

@Module({
  imports: [TypeOrmModule.forFeature([ServiceRequest, Vehicle]), ConsumerModule, VehicleModule, ServicesModule,GatewayModule],
  controllers: [ServiceRequestController],
  providers: [ServiceRequestService],
  exports: [ServiceRequestService],
})
export class ServiceRequestModule {}
