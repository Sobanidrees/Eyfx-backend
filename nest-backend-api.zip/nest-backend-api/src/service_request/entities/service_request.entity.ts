import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsString } from 'class-validator';
import { Consumer } from 'src/consumer/entities/consumer.entity';
import { Inspector } from 'src/inspector/entities/inspector.entity';
import { ServiceMetaData } from 'src/service_meta_data/entities/service_meta_data.entity';
import { Service } from 'src/services/entities/service.entity';
import { Status, packageType } from 'src/utils/constant/constants';
import { IsCustomDate } from 'src/utils/decorator/date.decorator';
import { IsCustomTime } from 'src/utils/decorator/time.decorator';
import { Vehicle } from 'src/vehicle/entities/vehicle.entity';
import { Column, CreateDateColumn, Entity, ManyToOne, OneToMany, PrimaryGeneratedColumn, UpdateDateColumn } from 'typeorm';

@Entity()
export class ServiceRequest {
  @PrimaryGeneratedColumn()
  id: number;

  @ApiProperty({ example: '12:30AM' })
  @IsNotEmpty()
  @IsString()
  @Column()
  @IsCustomTime()
  time: string;

  @ApiProperty({ example: 'Basic' })
  @IsNotEmpty()
  @Column({ type: 'enum', enum: packageType, default: packageType.Basic })
  packageType: packageType;

  @ApiProperty({ example: 'Requested' })
  @Column({ type: 'enum', enum: Status, default: Status.Requested })
  status: Status;

  @ApiProperty({ example: 'DD/MM/YYYY' })
  @IsNotEmpty()
  @IsString()
  @Column()
  @IsCustomDate()
  date: string;

  @ManyToOne(() => Consumer, consumer => consumer.serviceRequest, { onDelete: 'CASCADE' })
  consumer: Consumer;

  @OneToMany(() => ServiceMetaData, metaData => metaData.serviceRequest)
  metaData: ServiceMetaData[];

  @ManyToOne(() => Vehicle, vehicle => vehicle.serviceRequest, { onDelete: 'CASCADE' })
  vehicle: Vehicle;

  @ManyToOne(() => Service, service => service.serviceRequests)
  service: Service;

  @ManyToOne(() => Inspector, inspector => inspector.serviceRequests, { onDelete: 'CASCADE' })
  inspector: Inspector;

  @ApiProperty({ example: '2023-07-19T12:45:48.911Z' })
  @CreateDateColumn({
    type: 'timestamp',
    default: () => 'CURRENT_TIMESTAMP(6)',
  })
  public createdAt: Date;

  @ApiProperty({ example: '2023-07-19T12:45:48.911Z' })
  @UpdateDateColumn({
    type: 'timestamp',
    default: () => 'CURRENT_TIMESTAMP(6)',
    onUpdate: 'CURRENT_TIMESTAMP(6)',
  })
  public updatedAt: Date;
}
