import { BadRequestException, ConflictException, HttpException, HttpStatus, Injectable, NotFoundException } from '@nestjs/common';
import { CreateServiceRequestDto } from './dto/create-service_request.dto';
import { Not, Repository } from 'typeorm';
import { ServiceRequest } from './entities/service_request.entity';
import { InjectRepository } from '@nestjs/typeorm';
import { ConsumerService } from 'src/consumer/consumer.service';
import { Vehicle } from 'src/vehicle/entities/vehicle.entity';
import { ServicesService } from 'src/services/services.service';
import { Consumer } from 'src/consumer/entities/consumer.entity';
import { UpdateServiceRequestDto } from './dto/update-service_request.dto';
import { Status } from 'src/utils/constant/constants';

@Injectable()
export class ServiceRequestService {
  constructor(
    @InjectRepository(ServiceRequest) private serviceRequestRepository: Repository<ServiceRequest>,
    @InjectRepository(Vehicle) private vehicleRepository: Repository<Vehicle>,
    private readonly consumerService: ConsumerService,
    private servicesService: ServicesService,
  ) {}
  async create(body: CreateServiceRequestDto): Promise<ServiceRequest> {
    try {
      let consumer: Consumer = null;
      consumer = await this.consumerService.findOneByPhoneNumber(body.phoneNumber);
      if (consumer) {
        const ConsumerPendingSRs = await this.serviceRequestRepository.find({
          where: {
            consumer: {
              id: consumer.id,
            },
            status: Not(Status.ReportShared),
          },
        });
        if (ConsumerPendingSRs.length !== 0) {
          throw new ConflictException('You have already a service request in pending status.');
        }
      }
      if (!consumer) {
        consumer = await this.consumerService.create({ phoneNumber: body.phoneNumber, fullName: body.fullName, address: body.address });
      }
      var Consumervehicle = await this.vehicleRepository.findOne({
        where: {
          year: body.year,
          make: body.make,
          model: body.model,
          consumer: {
            id: consumer.id,
          },
        },
      });
      if (!Consumervehicle) {
        Consumervehicle = await this.vehicleRepository.save(this.vehicleRepository.create({ year: body.year, make: body.make, model: body.model, consumer: { id: consumer.id } }));
      }
      const service = await this.servicesService.findOneByName(body.service);
      const sr = await this.serviceRequestRepository.save(
        this.serviceRequestRepository.create({ time: body.time, date: body.date, packageType: body.packageType, vehicle: Consumervehicle, consumer: consumer, service: service }),
      );
      return sr;
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  async findAll(): Promise<ServiceRequest[]> {
    try {
      return this.serviceRequestRepository.find();
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  async findOne(id: number): Promise<ServiceRequest> {
    try {
      const serviceRequest = await this.serviceRequestRepository.findOne({ where: { id }, relations: ['inspector', 'vehicle', 'consumer'] });
      if (!serviceRequest) throw new HttpException({ message: `${`Service Request not found with id ${id}`}` }, HttpStatus.NOT_FOUND);
      return serviceRequest;
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  async update(id: number, body: UpdateServiceRequestDto): Promise<ServiceRequest> {
    try {
      const serviceRequest = await this.findOne(id);
      this.serviceRequestRepository.merge(serviceRequest, { ...serviceRequest, status: body.status });
      return this.serviceRequestRepository.save(serviceRequest);
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  async remove(id: number): Promise<Object> {
    try {
      const ServiceRequest = await this.findOne(id);
      if (ServiceRequest) return await this.serviceRequestRepository.delete(id);
      throw new NotFoundException();
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }
}
