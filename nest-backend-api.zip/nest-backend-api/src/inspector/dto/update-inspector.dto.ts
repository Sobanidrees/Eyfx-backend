import { ApiProperty, PartialType } from '@nestjs/swagger';
import { CreateInspectorDto } from './create-inspector.dto';
import { IsBoolean } from 'class-validator';
export class UpdateInspectorOtpStatusDto extends PartialType(CreateInspectorDto) {
  
  @ApiProperty({
    example: true,
    description: 'Inspector verification',
    format: 'boolean',
  })
  @IsBoolean()
  otpVerified: boolean = null;
}
