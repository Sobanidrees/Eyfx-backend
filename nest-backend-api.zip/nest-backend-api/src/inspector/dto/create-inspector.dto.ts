import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsString } from 'class-validator';
import { IsEmiratesId } from 'src/utils/decorator/emirates-id.decorator';
import { IsFullName } from 'src/utils/decorator/full-name.decorator';
import { IsPhoneNumber } from 'src/utils/decorator/phone-number.decorator';

export class CreateInspectorDto {
  @ApiProperty({
    example: '+971123456789',
    description: 'The phone number of the account',
    format: 'string',
  })
  @IsString()
  @IsNotEmpty()
  @IsPhoneNumber()
  phoneNumber: string;

  @ApiProperty({
    example: 'M Soban Idrees',
    description: 'Name of Inspector',
    format: 'string',
  })
  @IsString()
  @IsNotEmpty()
  @IsFullName()
  fullName: string;

  @ApiProperty({
    example: '784-1234-1234567-1',
    description: 'Emirates id of inspector',
    format: 'string',
  })
  @IsString()
  @IsNotEmpty()
  @IsEmiratesId()
  emiratesId: string;
}
