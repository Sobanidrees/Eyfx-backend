import { ApiProperty } from '@nestjs/swagger';
import { IsString } from 'class-validator';

export class UpdateInspectorProfileDto {
  @ApiProperty({ example: 'I am a expert and tarined Mechanic' })
  @IsString()
  bio: string;

  @ApiProperty({ example: 'https://www.google.com/url?sa=i&url=https%3A%2F%2Funsplash' })
  profileImage: any;
}
