import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  UseGuards,
  BadRequestException,
  Res,
  HttpException,
  HttpStatus,
  Req,
  UnauthorizedException,
  Query,
} from '@nestjs/common';
import { InspectorService } from './inspector.service';
import { CreateInspectorDto } from './dto/create-inspector.dto';
import { ApiBearerAuth, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { Inspector } from './entities/inspector.entity';
import { AuthService } from 'src/auth/auth.service';
import { LoginDto } from '../auth/dto/login-dto';
import { VerifyOtpDto } from '../utils/otp/dto/verify-otp-dto';
import { OtpService } from 'src/utils/otp/otp.service';
import { ReSendOtpDto } from 'src/utils/otp/dto/resend-otp.dto';
import { Service } from 'src/services/entities/service.entity';
import { JwtAuthGuard } from 'src/auth/jwt-auth.gaurd';
import { ServiceRequest } from 'src/service_request/entities/service_request.entity';
import { InjectRepository } from '@nestjs/typeorm';
import { Not, Repository } from 'typeorm';
import { Status } from 'src/utils/constant/constants';
import { UpdateInspectorProfileDto } from './dto/update-inspector-profile.dto';
import { CoreServicesService } from 'src/core_services/core-service.service';
import { CoreService } from 'src/core_services/entities/core_services.entity';
import { S3Service } from 'src/utils/s3/s3.service';

@ApiTags('Inspector')
@Controller('inspector')
export class InspectorController {
  constructor(
    private readonly inspectorService: InspectorService,
    private readonly authService: AuthService,
    private readonly otpService: OtpService,
    private s3Service: S3Service,
    private readonly coreServiceServices: CoreServicesService,
    @InjectRepository(ServiceRequest) private serviceRequestRepository: Repository<ServiceRequest>,
    @InjectRepository(Inspector) private inspectorRepository: Repository<Inspector>,
  ) {}

  @ApiOperation({
    description: 'A successful hit can return inspector object',
    summary: 'Register Inspector',
  })
  @ApiResponse({ status: 201, description: ' Successfully created inspector.', type: Inspector })
  @Post('/register')
  async create(@Body() body: CreateInspectorDto): Promise<Inspector> {
    try {
      const inspector = await this.inspectorService.getInspectorByPhoneNumber(body.phoneNumber);
      if (!inspector) {
        this.otpService.generateAndSendOTP(body.phoneNumber);
        return await this.inspectorService.create(body);
      } else {
        throw new HttpException('User already registered with these credentials', HttpStatus.BAD_REQUEST);
      }
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  @ApiOperation({
    description: 'A successful hit can return inspector',
    summary: 'Login Inspector',
  })
  @ApiResponse({ status: 200, description: 'Add Otp please.....' })
  @Post('/login')
  async login(@Body() body: LoginDto): Promise<Inspector> {
    try {
      const inspector = await this.inspectorService.getInspectorByPhoneNumber(body.phoneNumber);
      if (!inspector) throw new UnauthorizedException('Invalid phone number');
      this.otpService.generateAndSendOTP(inspector.phoneNumber);
      return inspector;
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }
  @ApiOperation({
    description: 'A successful hit can return JWT token',
    summary: 'Verify OTP',
  })
  @ApiResponse({ status: 200, description: 'Successfully Login' })
  @Post('verify_otp')
  async verify_otp(@Body() body: VerifyOtpDto): Promise<string> {
    try {
      const inspector = await this.inspectorService.getInspectorByPhoneNumber(body.phoneNumber);
      const otp = await this.otpService.findWithPhoneNumberAndOtp({ phoneNumber: body.phoneNumber, otp: body.otp });

      if (!inspector.otpVerified) {
        await this.inspectorService.update(inspector.id, { ...inspector, otpVerified: true });
      }
      await this.otpService.remove(otp.id);
      return this.authService.generateTokenForInspector({ id: inspector.id, phoneNumber: inspector.phoneNumber, fullName: inspector.fullName, emiratesId: inspector.emiratesId });
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }
  @ApiOperation({
    description: 'A successful hit can return Sub Services',
    summary: 'Sub Services for inspector',
  })
  @ApiResponse({ status: 200, description: 'Services', type: Service })
  @Get('inspection/services')
  @ApiBearerAuth(process.env.X_ACCESS_TOKEN)
  @UseGuards(JwtAuthGuard)
  async inspection_services(): Promise<CoreService[]> {
    try {
      return this.coreServiceServices.findAll();
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  @ApiOperation({
    description: 'A successful hit can return new otp',
    summary: 'Resend OTP',
  })
  @ApiResponse({ status: 200, description: 'Successfully receive new Otp' })
  @Post('resend_otp')
  async resend_otp(@Body() body: ReSendOtpDto, @Res() response) {
    try {
      this.otpService.generateAndSendOTP(body.phoneNumber);
      return response.status(200).json({ message: 'OTP sent successfully!' });
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  @ApiOperation({
    description: 'A successful hit can return all inspectors',
    summary: 'Get All Inspectors',
  })
  @ApiResponse({
    status: 200,
    description: 'Successfully retrieved All Inspectors.',
    type: [Inspector],
  })
  @Get()
  @ApiBearerAuth(process.env.X_ACCESS_TOKEN)
  @UseGuards(JwtAuthGuard)
  async findAll(): Promise<Inspector[]> {
    try {
      return await this.inspectorService.findAll();
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  @ApiOperation({
    description: 'A successful hit can return inspector against id',
    summary: 'Get Inspector Against Id',
  })
  @ApiResponse({ status: 200, description: 'Successfully retrieved inspector against id .', type: Inspector })
  @ApiBearerAuth(process.env.X_ACCESS_TOKEN)
  @UseGuards(JwtAuthGuard)
  @Get(':id')
  async findOne(@Param('id') id: string): Promise<Inspector> {
    try {
      return await this.inspectorService.findOne(+id);
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  @ApiOperation({
    description: 'A successful hit can return Inspector',
    summary: 'Update Inspector Profile',
  })
  @ApiResponse({ status: 200, description: 'Successfully update inspector .', type: Inspector })
  @ApiBearerAuth(process.env.X_ACCESS_TOKEN)
  @UseGuards(JwtAuthGuard)
  @Patch(':id')
  async update(@Param('id') id: string, @Body() body: UpdateInspectorProfileDto): Promise<Inspector> {
    try {
      const inspector = await this.inspectorService.findOne(+id);
      if (body.profileImage && typeof(body.profileImage) !== "string") {
        const s3Response = await this.s3Service.uploadFile(body.profileImage);
        if (s3Response.Location) {
          body.profileImage = s3Response.Location;
        }
      }
      this.inspectorRepository.merge(inspector, { ...inspector, profileImage: body.profileImage, bio: body.bio });
      return this.inspectorRepository.save(inspector);
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  @ApiOperation({
    description: 'A successful hit can delete inspector against id',
    summary: 'Delete Inspector Against Id',
  })
  @ApiBearerAuth(process.env.X_ACCESS_TOKEN)
  @UseGuards(JwtAuthGuard)
  @Delete(':id')
  async remove(@Param('id') id: string) {
    try {
      return await this.inspectorService.remove(+id);
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  @ApiOperation({
    description: 'A successful hit can return all Inspector Service requests that are In Progress',
    summary: 'Get All In Progress Servive Request for Inspector',
  })
  @ApiResponse({
    status: 200,
    description: 'Successfully retrieved SRs.',
    type: [ServiceRequest],
  })
  @Get('InspectorSrs/:id')
  @ApiBearerAuth(process.env.X_ACCESS_TOKEN)
  @UseGuards(JwtAuthGuard)
  async getInspectorInProgressSR(@Param('id') id: string, @Query('status') status: Status): Promise<ServiceRequest[] | ServiceRequest> {
    try {
      if (status === Status.InProgress) {
        return await this.serviceRequestRepository.findOne({
          where: {
            inspector: {
              id: +id,
            },
            status: Status[status],
          },
          relations: ['consumer', 'vehicle'],
        });
      }

      return await this.serviceRequestRepository.find({
        where: {
          inspector: {
            id: +id,
          },
          status: Status[status],
        },
        relations: ['consumer', 'vehicle'],
      });
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }
}
