import { HttpException, HttpStatus, Injectable, NotFoundException, UnauthorizedException } from '@nestjs/common';
import { CreateInspectorDto } from './dto/create-inspector.dto';
import { UpdateInspectorOtpStatusDto } from './dto/update-inspector.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { Inspector } from './entities/inspector.entity';
import { Repository } from 'typeorm';

@Injectable()
export class InspectorService {
  constructor(@InjectRepository(Inspector) private inspectorRepository: Repository<Inspector>) {}
  async create(body: CreateInspectorDto): Promise<Inspector> {
    return this.inspectorRepository.save(this.inspectorRepository.create(body)).catch((err: any) => {
      throw new HttpException(
        {
          message: `${err}`,
        },
        HttpStatus.CONFLICT,
      );
    });
  }

  async findAll(): Promise<Inspector[]> {
    try {
      return this.inspectorRepository.find();
    } catch (e) {
      throw new HttpException(e.message, e.statusCode);
    }
  }

  async findOne(id: number): Promise<Inspector> {
    try {
      const inspector = this.inspectorRepository.findOne({ where: { id } });
      if (!inspector) throw new HttpException({ message: `${`Inspector not found with id ${id}`}` }, HttpStatus.NOT_FOUND);
      return inspector;
    } catch (e) {
      throw new HttpException(e.message, e.statusCode);
    }
    // TODO: Implement logger here
  }

  async update(id: number, body: UpdateInspectorOtpStatusDto): Promise<Inspector> {
    try {
      const inspector = await this.findOne(id);
      this.inspectorRepository.merge(inspector, body);
      return this.inspectorRepository.save(inspector);
    } catch (e) {
      throw new HttpException(e.message, e.statusCode);
    }
  }

  async remove(id: number): Promise<Object> {
    try {
      const inspector = await this.findOne(id);
      if (inspector) return this.inspectorRepository.delete(id);
      throw new NotFoundException();
    } catch (e) {
      throw new HttpException(e.message, e.statusCode);
    }
  }

  async getInspectorByPhoneNumber(phoneNumber: string): Promise<Inspector> {
    try {
      return await this.inspectorRepository.findOne({
        where: {
          phoneNumber: phoneNumber
        }
      });
    } catch (e) {
      throw new HttpException(e.message, e.statusCode);
    }
  }
}
