import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsString } from 'class-validator';
import { ServiceRequest } from 'src/service_request/entities/service_request.entity';
import { IsEmiratesId } from 'src/utils/decorator/emirates-id.decorator';
import { IsFullName } from 'src/utils/decorator/full-name.decorator';
import { IsPhoneNumber } from 'src/utils/decorator/phone-number.decorator';
import { Column, CreateDateColumn, Entity, OneToMany, PrimaryGeneratedColumn, UpdateDateColumn } from 'typeorm';

@Entity()
export class Inspector {
  @PrimaryGeneratedColumn()
  id: number;

  @ApiProperty({ example: '+971123456789' })
  @IsString()
  @IsNotEmpty()
  @Column({ unique: true })
  @IsPhoneNumber()
  phoneNumber: string;

  @ApiProperty({ example: 'soban' })
  @IsString()
  @Column()
  @IsFullName()
  fullName: string;

  @ApiProperty({ example: '784-1234-1234567-1' })
  @IsNotEmpty()
  @IsString()
  @IsEmiratesId()
  @Column({ unique: true })
  emiratesId: string;

  @ApiProperty({ example: 'I am a expert and tarined Mechanic' })
  @IsString()
  @Column({ nullable: true })
  bio: string;

  @ApiProperty({ example: 'https://www.google.com/url?sa=i&url=https%3A%2F%2Funsplash' })
  @IsString()
  @Column({ nullable: true })
  profileImage: string;

  @ApiProperty({ example: true })
  @Column({ default: null })
  otpVerified: boolean;

  @OneToMany(() => ServiceRequest, serviceRequest => serviceRequest.inspector)
  serviceRequests: ServiceRequest[];

  @ApiProperty({ example: '2023-07-19T12:45:48.911Z' })
  @CreateDateColumn({
    type: 'timestamp',
    default: () => 'CURRENT_TIMESTAMP(6)',
  })
  public createdAt: Date;

  @ApiProperty({ example: '2023-07-19T12:45:48.911Z' })
  @UpdateDateColumn({
    type: 'timestamp',
    default: () => 'CURRENT_TIMESTAMP(6)',
    onUpdate: 'CURRENT_TIMESTAMP(6)',
  })
  public updatedAt: Date;
}
