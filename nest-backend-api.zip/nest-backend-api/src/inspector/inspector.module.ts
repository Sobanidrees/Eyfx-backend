import { Module } from '@nestjs/common';
import { InspectorService } from './inspector.service';
import { InspectorController } from './inspector.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Inspector } from './entities/inspector.entity';
import { AuthModule } from 'src/auth/auth.module';
import { OtpModule } from 'src/utils/otp/otp.module';
import { ServiceRequest } from 'src/service_request/entities/service_request.entity';
import { CoreService } from 'src/core_services/entities/core_services.entity';
import { CoreServicesModule } from 'src/core_services/core_services.module';
import { S3Service } from 'src/utils/s3/s3.service';

@Module({
  imports: [TypeOrmModule.forFeature([Inspector, CoreService, ServiceRequest]), AuthModule, OtpModule, CoreServicesModule],
  controllers: [InspectorController],
  providers: [InspectorService, S3Service],
  exports: [InspectorService],
})
export class InspectorModule {}
