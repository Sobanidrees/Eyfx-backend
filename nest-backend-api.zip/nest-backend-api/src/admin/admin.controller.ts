import { Controller, Get, Post, Body, BadRequestException, NotFoundException, HttpException, HttpStatus, UseGuards, Patch, Param } from '@nestjs/common';
import { AdminService } from './services/admin.service';
import { CreateAdminDto } from './dto/create-admin.dto';
import { ApiBearerAuth, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { Admin } from './entities/admin.entity';
import { AdminLoginDto } from './dto/admin-login.dto';
import { AuthService } from 'src/auth/auth.service';
import * as bcrypt from 'bcrypt';
import { Inspector } from 'src/inspector/entities/inspector.entity';
import { InspectorServiceRequestDto } from './dto/inspector-tasks.dto';
import { ServiceRequest } from 'src/service_request/entities/service_request.entity';
import { InspectorServiceRequest } from './services/inspector-service-request.service';
import { UpdateServiceRequestByAdminDto } from './dto/update-service-request.dto';
import { UpdateServiveRequestService } from './services/update-service-request.service';
import { JwtAuthGuard } from 'src/auth/jwt-auth.gaurd';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Status } from 'src/utils/constant/constants';
import { GatewayService } from 'src/gateway/gateway.service';
@ApiTags('Admin')
@Controller('admin')
export class AdminController {
  constructor(
    private readonly adminService: AdminService,
    private readonly authService: AuthService,
    private readonly inspectorServiceRequest: InspectorServiceRequest,
    private readonly updateServiceRequestService: UpdateServiveRequestService,
    @InjectRepository(Inspector) private inspectorRepository: Repository<Inspector>,
    @InjectRepository(ServiceRequest) private serviceRequestRepository: Repository<ServiceRequest>,
    private readonly socketGateway: GatewayService,
  ) { }

  @ApiOperation({
    description: 'A successful hit can return admin object',
    summary: 'Register Admin',
  })
  @ApiResponse({ status: 201, description: 'Successfully retrieved Admin.', type: Admin })
  @Post('/register')
  async create(@Body() body: CreateAdminDto): Promise<Admin> {
    try {
      const admin = await this.adminService.findOne(body.email);
      if (admin) throw new HttpException('You are already registered', HttpStatus.BAD_REQUEST);
      const hashedPassword = await bcrypt.hash(body.password, 10);
      return this.adminService.create({ ...body, password: hashedPassword });
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  @ApiOperation({
    description: 'A successful hit can return Jwt token',
    summary: 'Login Admin',
  })
  @ApiResponse({ status: 200, description: 'Login successfuly' })
  @Post('/login')
  async login(@Body() body: AdminLoginDto): Promise<string> {
    try {
      const admin = await this.adminService.findOne(body.email);
      if (!admin) throw new NotFoundException('Email not Found! please register first.');

      if (await bcrypt.compare(body.password, admin.password)) {
        return this.authService.generateTokenForAdmin({ id: admin.id, email: admin.email, fullName: admin.fullName });
      }
      throw new NotFoundException('Invalid email or password!');
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  @ApiOperation({
    description: 'A successful hit can return updated service request',
    summary: 'Assign Inspector to SR',
  })
  @ApiResponse({ status: 200, description: 'Successfuly Assigned' })
  @Patch('/inspectorAssignedServiceRequest')
  @ApiBearerAuth(process.env.X_ACCESS_TOKEN)
  @UseGuards(JwtAuthGuard)
  async inspectorAssignedServiceRequest(@Body() body: InspectorServiceRequestDto): Promise<ServiceRequest> {
    const Sr = await this.inspectorServiceRequest.update(body);
    this.socketGateway.updateServiceRequestStatus(Sr);
    return Sr;
  }

  @ApiOperation({
    description: 'A successful hit can return updated service request',
    summary: 'Update SR Date and Time',
  })
  @ApiResponse({ status: 200, description: 'Successfuly Assigned' })
  @Patch('/updateServiceRequestByAdmin')
  @ApiBearerAuth(process.env.X_ACCESS_TOKEN)
  @UseGuards(JwtAuthGuard)
  async updateServiceRequestByAdmin(@Body() body: UpdateServiceRequestByAdminDto): Promise<ServiceRequest> {
    return this.updateServiceRequestService.updateServiceRequest(body);
  }

  @ApiOperation({
    description: 'A successful hit can return all admins',
    summary: 'Get All Admins',
  })
  @ApiResponse({ status: 200, description: 'Successfully retrieved All Admin.', type: [Admin] })
  @ApiBearerAuth(process.env.X_ACCESS_TOKEN)
  @UseGuards(JwtAuthGuard)
  @Get()
  async findAll(): Promise<Admin[]> {
    try {
      return this.adminService.findAll();
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  @ApiOperation({
    description: 'A successful hit can return All Inspector',
    summary: 'All Inspectors',
  })
  @ApiResponse({ status: 200, description: 'Successfully return Inspectors.', type: Inspector })
  @UseGuards(JwtAuthGuard)
  @Get('allInspectors')
  @ApiBearerAuth(process.env.X_ACCESS_TOKEN)
  async allInspectors(): Promise<Inspector[]> {
    try {
      return this.inspectorRepository.find({ relations: ['serviceRequests'] });
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  @ApiOperation({
    description: 'A successful hit can return all Service Requests in requested status',
    summary: 'Get All Requested Service Requests',
  })
  @ApiResponse({
    status: 200,
    description: 'Successfully retrieved All Requested Service Requests.',
    type: [ServiceRequest]
  })
  @UseGuards(JwtAuthGuard)
  @Get('/findAllSrsPending/:status')
  @ApiBearerAuth(process.env.X_ACCESS_TOKEN)
  async findAllSrsPending(@Param('status') status: Status): Promise<ServiceRequest[]> {
    try {
      return this.serviceRequestRepository.find(
        {
          where: { status: status },
          relations: ['consumer', 'vehicle', 'service'],
          order: { createdAt: 'DESC' }
        }
      );
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }
}

