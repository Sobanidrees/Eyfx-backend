import { Column, CreateDateColumn, Entity, PrimaryGeneratedColumn, UpdateDateColumn } from 'typeorm';
import { IsEmail, IsNotEmpty, IsString, MaxLength, MinLength } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
import { IsFullName } from 'src/utils/decorator/full-name.decorator';
import { IsStrongPassword } from 'src/utils/decorator/password.decorator';

@Entity()
export class Admin {
  @PrimaryGeneratedColumn()
  id: number;

  @ApiProperty({ example: 'msobanidrees@gmail.com' })
  @IsString()
  @IsNotEmpty()
  @Column({ unique: true })
  @IsEmail()
  email: string;

  @ApiProperty({ example: 'soban' })
  @IsString()
  @IsNotEmpty()
  @Column()
  @IsFullName()
  fullName: string;

  @ApiProperty({ example: '************' })
  @IsString()
  @IsNotEmpty()
  @Column()
  @IsStrongPassword()
  @MinLength(8)
  @MaxLength(20)
  password: string;

  @ApiProperty({ example: '2023-07-19T12:45:48.911Z' })
  @CreateDateColumn({
    type: 'timestamp',
    default: () => 'CURRENT_TIMESTAMP(6)',
  })
  public createdAt: Date;

  @ApiProperty({ example: '2023-07-19T12:45:48.911Z' })
  @UpdateDateColumn({
    type: 'timestamp',
    default: () => 'CURRENT_TIMESTAMP(6)',
    onUpdate: 'CURRENT_TIMESTAMP(6)',
  })
  public updatedAt: Date;
}
