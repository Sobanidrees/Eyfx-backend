import { Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { ServiceRequest } from 'src/service_request/entities/service_request.entity';
import { BadRequestException, HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { UpdateServiceRequestByAdminDto } from '../dto/update-service-request.dto';

@Injectable()
export class UpdateServiveRequestService {
  constructor(@InjectRepository(ServiceRequest) private serviceRequestRepository: Repository<ServiceRequest>) {}
  async findOneById(id: number): Promise<ServiceRequest> {
    try {
      const serviceRequest = await this.serviceRequestRepository.findOne({ where: { id } });
      if (!serviceRequest) throw new HttpException({ message: `${`Service Request not found with id ${id}`}` }, HttpStatus.NOT_FOUND);
      return serviceRequest;
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  async updateServiceRequest(body: UpdateServiceRequestByAdminDto): Promise<ServiceRequest> {
    try {
      const sr = await this.findOneById(body.serviceRequestId);
      this.serviceRequestRepository.merge(sr, { ...sr, date: body.date, time: body.time });
      return this.serviceRequestRepository.save(sr);
    } catch (e) {
      throw new HttpException(e.message, e.statusCode);
    }
  }
}
