import { BadRequestException, HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { CreateAdminDto } from '../dto/create-admin.dto';
import { Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { Admin } from '../entities/admin.entity';

@Injectable()
export class AdminService {
  constructor(@InjectRepository(Admin) private adminRepository: Repository<Admin>) {}
  async create(body: CreateAdminDto): Promise<Admin> {
    return this.adminRepository.save(this.adminRepository.create(body)).catch((err: any) => {
      throw new HttpException(
        {
          message: `${err}`,
        },
        HttpStatus.CONFLICT,
      );
    });
  }

  async findAll(): Promise<Admin[]> {
    try {
      return this.adminRepository.find();
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  async findOne(email: string): Promise<Admin> {
    try {
      return this.adminRepository.findOne({ where: { email } });
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }
}
