import { BadRequestException, HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { DeepPartial, Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { ServiceRequest } from 'src/service_request/entities/service_request.entity';
import { InspectorServiceRequestDto } from '../dto/inspector-tasks.dto';
import { Inspector } from 'src/inspector/entities/inspector.entity';
import { Status } from 'src/utils/constant/constants';

@Injectable()
export class InspectorServiceRequest {
  constructor(
    @InjectRepository(ServiceRequest) private serviceRequestRepository: Repository<ServiceRequest>,
    @InjectRepository(Inspector) private inspectorRepository: Repository<Inspector>,
  ) {}

  async findOneById(id: number): Promise<ServiceRequest> {
    try {
      const serviceRequest = await this.serviceRequestRepository.findOne({ where: { id }, relations: ['consumer', 'vehicle'] });
      if (!serviceRequest) throw new HttpException({ message: `${`Service Request not found with id ${id}`}` }, HttpStatus.NOT_FOUND);
      return serviceRequest;
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  async findInspectorById(id: number): Promise<Inspector> {
    try {
      const inspector = await this.inspectorRepository.findOne({ where: { id } });
      if (!inspector) throw new HttpException({ message: `${`Inspector not found with id ${id}`}` }, HttpStatus.NOT_FOUND);
      return inspector;
    } catch (e) {
      throw new HttpException(e.message, e.statusCode);
    }
  }

  async update(body: InspectorServiceRequestDto): Promise<ServiceRequest> {
    try {
      const inspector = await this.findInspectorById(body.inspectorId);
      const sr = await this.findOneById(body.serviceRequestId);
      const updatedSr: DeepPartial<ServiceRequest> = {
        ...sr,
        inspector: inspector,
        status: Status.Pending,
      };
      this.serviceRequestRepository.merge(sr, updatedSr);
      return this.serviceRequestRepository.save(sr);
    } catch (e) {
      throw new HttpException(e.message, e.statusCode);
    }
  }
}
