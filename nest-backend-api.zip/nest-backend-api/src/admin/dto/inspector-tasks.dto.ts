import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsNumber } from 'class-validator';

export class InspectorServiceRequestDto {
  @ApiProperty({ example: '1' })
  @IsNumber()
  @IsNotEmpty()
  inspectorId: number;

  @ApiProperty({ example: '1' })
  @IsNumber()
  @IsNotEmpty()
  serviceRequestId: number;

}
