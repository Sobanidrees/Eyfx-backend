import { ApiProperty } from '@nestjs/swagger';
import { IsEmail, IsNotEmpty, IsString, MaxLength, MinLength } from 'class-validator';
import { IsFullName } from 'src/utils/decorator/full-name.decorator';
import { IsStrongPassword } from 'src/utils/decorator/password.decorator';

export class CreateAdminDto {
  @ApiProperty({ example: 'msobanidrees@gmail.com' })
  @IsString()
  @IsNotEmpty()
  @IsEmail()
  email: string;

  @ApiProperty({ example: 'soban' })
  @IsString()
  @IsNotEmpty()
  @IsFullName()
  fullName: string;

  @ApiProperty({ example: '************' })
  @IsString()
  @IsNotEmpty()
  @IsStrongPassword()
  @MinLength(8)
  @MaxLength(20)
  password: string;
}
