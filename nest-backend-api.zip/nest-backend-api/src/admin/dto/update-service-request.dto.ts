import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsNumber, IsString } from 'class-validator';
import { IsCustomDate } from 'src/utils/decorator/date.decorator';
import { IsCustomTime } from 'src/utils/decorator/time.decorator';

export class UpdateServiceRequestByAdminDto {
  @ApiProperty({ example: '1' })
  @IsNumber()
  @IsNotEmpty()
  serviceRequestId: number;

  @ApiProperty({ example: '12:30AM' })
  @IsNotEmpty()
  @IsCustomTime()
  @IsString()
  time: string;

  @ApiProperty({ example: 'DD/MM/YYYY' })
  @IsNotEmpty()
  @IsString()
  @IsCustomDate()
  date: string;
}
