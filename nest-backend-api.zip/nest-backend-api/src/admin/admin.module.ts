import { Module } from '@nestjs/common';
import { AdminService } from './services/admin.service';
import { AdminController } from './admin.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Admin } from './entities/admin.entity';
import { AuthModule } from 'src/auth/auth.module';
import { Inspector } from 'src/inspector/entities/inspector.entity';
import { ServiceRequest } from 'src/service_request/entities/service_request.entity';
import { InspectorServiceRequest } from './services/inspector-service-request.service';
import { UpdateServiveRequestService } from './services/update-service-request.service';
import { GatewayModule } from 'src/gateway/gateway.module';

@Module({
  imports: [TypeOrmModule.forFeature([Admin, Inspector, ServiceRequest]), AuthModule, GatewayModule],
  controllers: [AdminController],
  providers: [AdminService, InspectorServiceRequest, UpdateServiveRequestService],
})
export class AdminModule {}
