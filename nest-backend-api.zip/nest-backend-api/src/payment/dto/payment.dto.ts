import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsNumber } from 'class-validator';
import { packageType } from 'src/utils/constant/constants';

export class PaymentDto {
  @ApiProperty({
    example: 'Basic'
  })
  @IsNotEmpty()
  packageType: packageType;

  @ApiProperty({
    example: 1
  })
  @IsNotEmpty()
  @IsNumber()
  serviceRequestId: number;
}
