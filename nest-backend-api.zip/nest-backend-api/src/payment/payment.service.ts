import { Injectable } from '@nestjs/common';
import Stripe from 'stripe';
import { PaymentDto } from './dto/payment.dto';
import { Price, packageType } from 'src/utils/constant/constants';

@Injectable()
export class PaymentService {
  private readonly stripe: Stripe;

  constructor() {
    this.stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
      apiVersion: '2023-08-16',
    });
  }
  async createPaymentLink(body: PaymentDto): Promise<string> {
    if (body.packageType === packageType.Basic) {
      var price = Price.Basic;
    } else {
      price = Price.Premium;
    }

    const response = await this.stripe.paymentLinks.create({
      line_items: [
        {
          price: price,
          quantity: 1,
        },
      ],
      metadata: {
        service_request_id: body.serviceRequestId,
      },
    });

    return response.url;
  }
}
