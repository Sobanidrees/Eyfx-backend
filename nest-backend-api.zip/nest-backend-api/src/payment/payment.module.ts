import { Module } from '@nestjs/common';
import { PaymentService } from './payment.service';
import { PaymentController } from './payment.controller';
import Stripe from 'stripe';
import { ServiceRequestModule } from 'src/service_request/service_request.module';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ServiceRequest } from 'src/service_request/entities/service_request.entity';
import { GatewayModule } from 'src/gateway/gateway.module';

@Module({
  imports: [TypeOrmModule.forFeature([ServiceRequest]),ServiceRequestModule,GatewayModule],
  controllers: [PaymentController],
  providers: [PaymentService, Stripe],
})
export class PaymentModule {}
