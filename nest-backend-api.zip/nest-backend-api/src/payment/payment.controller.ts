import { BadRequestException, Body, Controller, Post } from '@nestjs/common';
import { PaymentService } from './payment.service';
import { ApiOperation, ApiTags } from '@nestjs/swagger';
import { PaymentDto } from './dto/payment.dto';
import { ServiceRequestService } from 'src/service_request/service_request.service';
import { Status } from 'src/utils/constant/constants';
import { InjectRepository } from '@nestjs/typeorm';
import { ServiceRequest } from 'src/service_request/entities/service_request.entity';
import { Repository } from 'typeorm';
import { GatewayService } from 'src/gateway/gateway.service';

@ApiTags('Payment')
@Controller('payment')
export class PaymentController {
  constructor(
    private readonly paymentService: PaymentService,
    private readonly serviceRequestService: ServiceRequestService,
    @InjectRepository(ServiceRequest) private serviceRequestRepository: Repository<ServiceRequest>,
    private readonly socketGateway: GatewayService,
  ) {}
  @ApiOperation({
    summary: 'Genrate Payment ',
  })
  @Post('generate-link')
  async generatePaymentLink(@Body() body: PaymentDto): Promise<{ link: string }> {
    const link = await this.paymentService.createPaymentLink(body);
    return { link };
  }

  @Post('HandleWebhook')
  async handleWebhook(@Body() event) {
    try {
      console.log(event);
      if (event.type === 'checkout.session.completed') {
        const id = event['data']['object']['metadata']['service_request_id'];
        console.log(id);
        const serviceRequest = await this.serviceRequestService.findOne(id);
        this.serviceRequestRepository.merge(serviceRequest, { ...serviceRequest, status: Status.Completed });
        const Sr = await this.serviceRequestRepository.save(serviceRequest);
        this.socketGateway.updateServiceRequestStatus(Sr);
        return event;
      }
    } catch (err) {
      throw new BadRequestException(err.message);
    }
  }
}
