import { ApiProperty } from '@nestjs/swagger';
import { IsNumber, IsString } from 'class-validator';
import { CoreService } from 'src/core_services/entities/core_services.entity';
import { ServiceRequest } from 'src/service_request/entities/service_request.entity';
import { Service } from 'src/services/entities/service.entity';
import { SubServices } from 'src/subservices/entities/subservice.entity';
import { Column, CreateDateColumn, Entity, PrimaryGeneratedColumn, UpdateDateColumn, ManyToOne, JoinColumn } from 'typeorm';

@Entity()
export class InspectionDetail {
  @PrimaryGeneratedColumn()
  id: number;

  @ApiProperty({ example: 'https://www.searchenginejournal.com/wp-content/uploads/2022/06/tineye-image-62c6eb4de8ce8-sej.png' })
  @IsString()
  @Column({ nullable: true })
  image: string;

  @ApiProperty({ example: 75.7 })
  @IsNumber()
  @Column({ type: 'float', nullable: true })
  ratingPercentage: number;

  @ApiProperty({ example: null })
  @Column({ default: null })
  ratingUnit: string;

  @ManyToOne(() => Service)
  @JoinColumn()
  service: Service;

  @ManyToOne(() => CoreService)
  @JoinColumn()
  coreServices: CoreService;

  @ManyToOne(() => SubServices)
  @JoinColumn()
  subServices: SubServices;

  @ManyToOne(() => ServiceRequest)
  @JoinColumn()
  serviceRequest: ServiceRequest;

  @IsNumber()
  @Column({ nullable: true })
  parentId: number;

  @ApiProperty({ example: '2023-07-19T12:45:48.911Z' })
  @CreateDateColumn({
    type: 'timestamp',
    default: () => 'CURRENT_TIMESTAMP(6)',
  })
  public createdAt: Date;

  @ApiProperty({ example: '2023-07-19T12:45:48.911Z' })
  @UpdateDateColumn({
    type: 'timestamp',
    default: () => 'CURRENT_TIMESTAMP(6)',
    onUpdate: 'CURRENT_TIMESTAMP(6)',
  })
  public updatedAt: Date;
}
