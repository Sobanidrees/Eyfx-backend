import { Module } from '@nestjs/common';
import { InspectionDetailController } from './inspection_detail.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { InspectionDetail } from './entities/inspection_details.entity';
import { InspectionDetailService } from './inspection_detail.service';
import { ServiceRequestModule } from 'src/service_request/service_request.module';
import { S3Service } from 'src/utils/s3/s3.service';

@Module({
  imports: [TypeOrmModule.forFeature([InspectionDetail]), ServiceRequestModule],
  controllers: [InspectionDetailController],
  providers: [InspectionDetailService, S3Service],
  exports: [InspectionDetailService],
})
export class InspectionDetailModule {}
