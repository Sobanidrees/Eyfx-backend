import { BadRequestException, HttpException, HttpStatus, Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { InspectionDetail } from './entities/inspection_details.entity';
import { Repository } from 'typeorm';
import { CreateInspectionDetailDto } from './dto/create-inspecton_detail.dto';
import { UpdateInspectionDetailDto } from './dto/update-inspection_detail.dto';
import { ServiceRequestService } from 'src/service_request/service_request.service';
import { packageType } from 'src/utils/constant/constants';
import { S3Service } from 'src/utils/s3/s3.service';

@Injectable()
export class InspectionDetailService {
  constructor(@InjectRepository(InspectionDetail) private inspectionDetail: Repository<InspectionDetail>, private readonly serviceRequestService: ServiceRequestService,
  private s3Service: S3Service) {}

  async create(body: CreateInspectionDetailDto): Promise<InspectionDetail> {
    
    const inspectionDetails = await this.inspectionDetail
      .save(
        this.inspectionDetail.create({
          image:body.image,
          ratingPercentage: body.ratingPercentage,
          ratingUnit: body.ratingUnit,
          serviceRequest: { id: body.serviceRequestId },
          service: { id: body.serviceId },
          coreServices: { id: body.coreServiceId },
          subServices: { id: body.subServiceId },
        }),
      )
      .catch((err: any) => {
        throw new HttpException(
          {
            message: `${err}`,
          },
          HttpStatus.CONFLICT,
        );
      });
    return inspectionDetails;
  }

  async findAll(): Promise<InspectionDetail[]> {
    try {
      return this.inspectionDetail.find();
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  async findOneById(id: number): Promise<InspectionDetail> {
    try {
      return this.inspectionDetail.findOne({ where: { id }, relations: ['service', 'coreServices', 'subServices'] });
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  async getInspectionDetailsByServiceRequest(serviceRequestId: number): Promise<InspectionDetail[]> {
    try {
      return this.inspectionDetail.find({
        where: {
          serviceRequest: {
            id: serviceRequestId,
          },
          service: {
            id: 1,
          },
        },
        relations: ['coreServices', 'subServices'],
      });
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  async ratingCalculations(serviceRequestId: number) {
    try {
      const AllData = await this.getInspectionDetailsByServiceRequest(serviceRequestId);
      const coreWeightageForPremium = [0.1, 0.15, 0.1, 0.1, 0.1, 0.05, 0.1, 0.15, 0.15];
      const coreWeightageForBasic = [0.2, 0.25, 0.15, 0.2, 0.2];
      const serviceRequest = await this.serviceRequestService.findOne(serviceRequestId);
      const coreServicesUnit = AllData.filter(core => {
        return core.subServices === null && core.coreServices !== null;
      }).map(core => {
        if (serviceRequest.packageType === packageType.Premium) {
          return core.ratingPercentage * coreWeightageForPremium[core.coreServices.id - 1];
        } else {
          return core.ratingPercentage * coreWeightageForBasic[core.coreServices.id - 1];
        }
      });
      let serviceSumRating = 0;
      for (let i = 0; i < coreServicesUnit.length; i++) {
        serviceSumRating = serviceSumRating + coreServicesUnit[i];
      }
      const service = AllData.filter(core => {
        return core.subServices === null && core.coreServices === null;
      });
      if (service.length === 0) {
        await this.inspectionDetail.save(
          this.inspectionDetail.create({
            image: null,
            ratingPercentage: serviceSumRating,
            ratingUnit: null,
            serviceRequest: { id: serviceRequestId },
            service: { id: 1 },
            coreServices: { id: null },
            subServices: { id: null },
          }),
        );
      }
      return await this.getInspectionDetailsByServiceRequest(serviceRequestId);
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  async update(id: number, body: UpdateInspectionDetailDto): Promise<InspectionDetail> {
    try {
      const service = await this.findOneById(id);
      this.inspectionDetail.merge(service, body);
      return this.inspectionDetail.save(service);
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  async remove(id: number): Promise<Object> {
    try {
      return this.inspectionDetail.delete(id);
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }
}
