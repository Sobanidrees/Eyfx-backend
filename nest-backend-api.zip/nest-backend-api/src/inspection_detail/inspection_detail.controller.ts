import { Controller, Get, Post, Body, Patch, Param, Delete, UseGuards, BadRequestException } from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { AuthGuard } from '@nestjs/passport';
import { InspectionDetailService } from './inspection_detail.service';
import { UpdateInspectionDetailDto } from './dto/update-inspection_detail.dto';
import { CoreServiceInspectionDto } from './dto/core-service-inspection.dto';
import { InspectionServices, Units } from 'src/utils/constant/constants';
import { S3Service } from 'src/utils/s3/s3.service';

@ApiTags('Inspection Detail')
@Controller('Inspection_Detail')
export class InspectionDetailController {
  constructor(private readonly inspectionDetailService: InspectionDetailService, private s3Service: S3Service) {}

  @ApiOperation({
    description: 'A successful hit can return inspection detail',
    summary: 'Add Inspection Detail',
  })
  @Post()
  @ApiBearerAuth(process.env.X_ACCESS_TOKEN)
  @UseGuards(AuthGuard('jwt'))
  async create(@Body() body: CoreServiceInspectionDto) {
    try {
      const serviceId = body.serviceId;
      const coreServiceId = body.coreServiceId;
      const serviceRequestId = body.serviceRequestId;
      const units = body.subAttribute.map(sub => {
        return InspectionServices[sub.subServiceName]['ratingUnit'][sub.ratingUnit];
      });

      let ratingUnitSum = 0;
      for (let i = 0; i < units.length; i++) {
        ratingUnitSum = ratingUnitSum + units[i];
      }
      const maxSumSubServices = [16, 32, 5, 26, 47, 7, 12, 26, 11];
      let coresServiceSum = (ratingUnitSum / maxSumSubServices[body.coreServiceId - 1]) * 100;
      await this.inspectionDetailService.create({
        image: null,
        ratingUnit: null,
        parentId: null,
        subServiceId: null,
        serviceId: serviceId,
        coreServiceId: coreServiceId,
        serviceRequestId: serviceRequestId,
        ratingPercentage: coresServiceSum,
      });
      await Promise.all(
        body.subAttribute.map(async details => {
          if (details && details.image) {
            const s3Response = await this.s3Service.uploadFile(details.image);
            if (s3Response.Location) {
              details.image = s3Response.Location;
              console.log(details);
            }
          }
          await this.inspectionDetailService.create({
            image: details.image ? details.image : null,
            ratingUnit: details.ratingUnit,
            parentId: details.parentId,
            subServiceId: details.subServiceId,
            serviceId: serviceId,
            coreServiceId: coreServiceId,
            serviceRequestId: serviceRequestId,
            ratingPercentage: details.ratingPercentage,
          });
        }),
      );
      return { message: 'Inspection details saved successfully' };
    } catch (e) {
      console.log(e);
      throw new BadRequestException(e.message);
    }
  }

  @ApiOperation({
    description: 'A successful hit can return all inspection detail',
    summary: 'Get All Inspection Detail',
  })
  @ApiBearerAuth(process.env.X_ACCESS_TOKEN)
  @UseGuards(AuthGuard('jwt'))
  @Get()
  findAll() {
    try {
      return this.inspectionDetailService.findAll();
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  @ApiOperation({
    description: 'A successful hit can return inspection detail against Id',
    summary: 'Get Inspection Detail Against Id',
  })
  @ApiBearerAuth(process.env.X_ACCESS_TOKEN)
  @UseGuards(AuthGuard('jwt'))
  @Get(':id')
  findOne(@Param('id') id: string) {
    try {
      return this.inspectionDetailService.findOneById(+id);
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  @ApiOperation({
    description: 'A successful hit can return inspection detail against id',
    summary: 'Update Inspection Detail Against Id',
  })
  @ApiBearerAuth(process.env.X_ACCESS_TOKEN)
  @UseGuards(AuthGuard('jwt'))
  @Patch(':id')
  update(@Param('id') id: string, @Body() updateInspectionDetailDto: UpdateInspectionDetailDto) {
    try {
      return this.inspectionDetailService.update(+id, updateInspectionDetailDto);
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  @ApiOperation({
    description: 'A successful hit can delete inspection detail against id',
    summary: 'Delete Inspection Detail Against Id',
  })
  @ApiBearerAuth(process.env.X_ACCESS_TOKEN)
  @UseGuards(AuthGuard('jwt'))
  @Delete(':id')
  remove(@Param('id') id: string) {
    try {
      return this.inspectionDetailService.remove(+id);
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  @ApiOperation({
    description: 'A successful hit can return inspection detail',
    summary: 'Get All Inspection Detail By Service Request',
  })
  @ApiBearerAuth(process.env.X_ACCESS_TOKEN)
  @UseGuards(AuthGuard('jwt'))
  @Get('get_inspection_details_By_Sr_Id/:id')
  getInspectionDetailsByServiceRequest(@Param('id') id: string) {
    try {
      return this.inspectionDetailService.getInspectionDetailsByServiceRequest(+id);
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }
}
