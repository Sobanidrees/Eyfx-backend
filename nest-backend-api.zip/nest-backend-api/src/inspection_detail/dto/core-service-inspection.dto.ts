import { ApiProperty } from '@nestjs/swagger';
import { IsArray, IsNumber, IsOptional, IsString, ValidateNested } from 'class-validator';
import { Units } from 'src/utils/constant/constants';
class SubAttributeItem {
  @ApiProperty({ example: 'url' })
  @IsOptional()
  image: any;

  @ApiProperty({ example: null })
  ratingUnit: string;

  @ApiProperty({ example: '1' })
  @IsNumber()
  subServiceId: number;

  @ApiProperty({ example: 'Radiator Core Support' })
  @IsString()
  subServiceName: string;

  @ApiProperty({ example: null })
  @IsNumber()
  ratingPercentage: number;

  @ApiProperty({ example: null })
  @IsNumber()
  parentId: number;
}

export class CoreServiceInspectionDto {
  @ApiProperty({ example: null })
  @IsNumber()
  serviceRequestId: number;

  @ApiProperty({ example: null })
  @IsNumber()
  serviceId: number;

  @ApiProperty({ example: null })
  @IsNumber()
  coreServiceId: number;

  @ApiProperty({ example: [{ image: 'url', ratingUnit: 'Accidented', subServiceId: 1, subServiceName : 'Radiator Core Support',ratingPercentage: null, parentId: null }] })
  @IsArray()
  @ValidateNested({ each: true })
  subAttribute: SubAttributeItem[];
}
