import { ApiProperty } from '@nestjs/swagger';
import { IsNumber, IsString } from 'class-validator';
import { Units } from 'src/utils/constant/constants';

export class CreateInspectionDetailDto {
  @ApiProperty({ example: 'https://www.searchenginejournal.com/wp-content/uploads/2022/06/tineye-image-62c6eb4de8ce8-sej.png' })
  image: any;

  @ApiProperty({ example: 75 })
  @IsNumber()
  ratingPercentage: number;

  @ApiProperty({ example: null })
  ratingUnit: string;

  @ApiProperty({ example: null })
  @IsNumber()
  serviceRequestId: number;

  @ApiProperty({ example: null })
  @IsNumber()
  serviceId: number;

  @ApiProperty({ example: null })
  @IsNumber()
  coreServiceId: number;

  @ApiProperty({ example: null })
  @IsNumber()
  subServiceId: number;

  @ApiProperty({ example: null })
  @IsNumber()
  parentId: number;
}
