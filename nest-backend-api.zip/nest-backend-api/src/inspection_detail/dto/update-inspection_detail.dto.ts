import { ApiProperty, PartialType } from '@nestjs/swagger';
import { IsNumber, IsString } from 'class-validator';
import { Units } from 'src/utils/constant/constants';
import { CreateInspectionDetailDto } from './create-inspecton_detail.dto';

export class UpdateInspectionDetailDto extends PartialType(CreateInspectionDetailDto) {
  @ApiProperty({ example: 'https://www.searchenginejournal.com/wp-content/uploads/2022/06/tineye-image-62c6eb4de8ce8-sej.png' })
  @IsString()
  image: string;

  @ApiProperty({ example: 75 })
  @IsNumber()
  ratingPercentage: number;

  @ApiProperty({ example: null })
  ratingUnit: string;

  @ApiProperty({ example: null })
  @IsNumber()
  serviceId: number;

  @ApiProperty({ example: null })
  @IsNumber()
  coreServiceId: number;

  @ApiProperty({ example: null })
  @IsNumber()
  subServiceId: number;

  @ApiProperty({ example: 'Radiator Core Support' })
  @IsString()
  subServiceName: string;
}
