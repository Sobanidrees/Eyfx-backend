import { BadRequestException, HttpException, HttpStatus, Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { CoreService } from './entities/core_services.entity';
import { CreateCoreServiceDto } from './dto/create-core-service.dto';
import { UpdateCoreServiceDto } from './dto/update-core-service.dto';

@Injectable()
export class CoreServicesService {
  constructor(@InjectRepository(CoreService) private coreServicesRepository: Repository<CoreService>) {}
  async create(body: CreateCoreServiceDto): Promise<CoreService> {
    const createdService = this.coreServicesRepository.create({ coreServiceName: body.coreServiceName, service: { id: body.serviceId } });
    return this.coreServicesRepository.save(createdService).catch((err: any) => {
      throw new HttpException(
        {
          message: `${err}`,
        },
        HttpStatus.CONFLICT,
      );
    });
  }

  async findAll(): Promise<CoreService[]> {
    try {
      return this.coreServicesRepository.find();
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  async findSubServicesWithCoreServiceID(id: number) {
    try {
      const coreService = await this.findOne(id);
      const subServicesWithParentIdNull = coreService.subServices.filter(sub => {
        return sub.parentId === null;
      });
      let coreServiceChilds = [];
      for (let i = 0; i < subServicesWithParentIdNull.length; i++) {
        const subsubServices = coreService.subServices.filter(sub => {
          return sub.parentId === subServicesWithParentIdNull[i].id;
        });
        const parent = { ...subServicesWithParentIdNull[i], childs: subsubServices };
        coreServiceChilds.push(parent);
      }
      return coreServiceChilds;
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  async findOne(id: number): Promise<CoreService> {
    try {
      return this.coreServicesRepository.findOne({ where: { id }, relations: ['subServices'] });
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  async update(id: number, body: UpdateCoreServiceDto): Promise<CoreService> {
    try {
      const coreService = await this.findOne(id);
      this.coreServicesRepository.merge(coreService, body);
      return this.coreServicesRepository.save(coreService);
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  async remove(id: number): Promise<Object> {
    const subService = await this.findOne(id);
    if (subService) return this.coreServicesRepository.delete(id);
    throw new NotFoundException();
  }
  catch(e) {
    throw new BadRequestException(e.message);
  }
}
