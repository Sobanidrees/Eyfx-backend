import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, CreateDateColumn, UpdateDateColumn, OneToMany } from 'typeorm';
import { Service } from 'src/services/entities/service.entity';
import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsString } from 'class-validator';
import { packageType } from 'src/utils/constant/constants';
import { SubServices } from 'src/subservices/entities/subservice.entity';

@Entity()
export class CoreService {
  @PrimaryGeneratedColumn()
  id: number;

  @ApiProperty({ example: 'Body Frame Accident Checklist' })
  @IsString()
  @IsNotEmpty()
  @Column({ unique: true })
  coreServiceName: string;

  @ApiProperty({ example: 'Basic' })
  @IsNotEmpty()
  @Column({ type: 'enum', enum: packageType, default: packageType.Basic })
  packageType: packageType;

  @ManyToOne(() => Service, service => service.coreServices, { onDelete: 'CASCADE' })
  service: Service;

  @OneToMany(() => SubServices, subServices => subServices.coreServices)
  subServices: SubServices[];

  @ApiProperty({ example: '2023-07-19T12:45:48.911Z' })
  @CreateDateColumn({
    type: 'timestamp',
    default: () => 'CURRENT_TIMESTAMP(6)',
  })
  public created_at: Date;

  @ApiProperty({ example: '2023-07-19T12:45:48.911Z' })
  @UpdateDateColumn({
    type: 'timestamp',
    default: () => 'CURRENT_TIMESTAMP(6)',
    onUpdate: 'CURRENT_TIMESTAMP(6)',
  })
  public updated_at: Date;
}
