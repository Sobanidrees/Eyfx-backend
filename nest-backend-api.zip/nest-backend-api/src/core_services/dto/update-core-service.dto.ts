import { ApiProperty, PartialType } from '@nestjs/swagger';
import { IsNotEmpty, IsString } from 'class-validator';
import { CreateCoreServiceDto } from './create-core-service.dto';

export class UpdateCoreServiceDto extends PartialType(CreateCoreServiceDto) {
  @ApiProperty({
    description: 'Name of a SubService',
    example: 'Body Frame Accident Checklist',
  })
  @IsNotEmpty()
  @IsString()
  coreServiceName: string;
}
