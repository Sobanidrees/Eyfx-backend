import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsString } from 'class-validator';
import { packageType } from 'src/utils/constant/constants';

export class CreateCoreServiceDto {
  @ApiProperty({
    description: 'Service ID of the selected service',
    example: '1',
  })
  @IsNotEmpty()
  serviceId: number;

  @ApiProperty({ example: 'Basic' })
  @IsNotEmpty()
  packageType: packageType;

  @ApiProperty({
    description: 'Name of a SubService',
    example: 'Body Frame Accident Checklist',
  })
  @IsNotEmpty()
  @IsString()
  coreServiceName: string;
}
