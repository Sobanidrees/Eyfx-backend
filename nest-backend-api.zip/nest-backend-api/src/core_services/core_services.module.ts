import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CoreService } from './entities/core_services.entity';
import { ServicesModule } from 'src/services/services.module';
import { CoreServicesController } from './core-service.controller';
import { CoreServicesService } from './core-service.service';

@Module({
  imports: [TypeOrmModule.forFeature([CoreService]), ServicesModule],
  controllers: [CoreServicesController],
  providers: [CoreServicesService],
  exports: [CoreServicesService]
})
export class CoreServicesModule {}
