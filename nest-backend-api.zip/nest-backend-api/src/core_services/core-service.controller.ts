import { Controller, Get, Post, Body, Patch, Param, Delete, BadRequestException, HttpException, HttpStatus, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { AuthGuard } from '@nestjs/passport';
import { CoreService } from './entities/core_services.entity';
import { CoreServicesService } from './core-service.service';
import { CreateCoreServiceDto } from './dto/create-core-service.dto';
import { UpdateCoreServiceDto } from './dto/update-core-service.dto';

@ApiTags('CoreService')
@Controller('core-service')
export class CoreServicesController {
  constructor(private readonly coreServicesService: CoreServicesService) {}
  @ApiBearerAuth(process.env.X_ACCESS_TOKEN)
  @UseGuards(AuthGuard('jwt'))
  @Post()
  async create(@Body() body: CreateCoreServiceDto): Promise<CoreService> {
    try {
      return this.coreServicesService.create(body);
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  @ApiOperation({
    description: 'A successful hit can return all coreservices',
    summary: 'Get All CoreServices',
  })
  @ApiResponse({ status: 200, description: 'Successfully retrieved All Core Services.', type: [CoreService] })
  @ApiBearerAuth(process.env.X_ACCESS_TOKEN)
  @UseGuards(AuthGuard('jwt'))
  @Get()
  async findAll(): Promise<CoreService[]> {
    try {
      return this.coreServicesService.findAll();
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  @ApiOperation({
    description: 'A successful hit can return core service against Id',
    summary: 'Get CoreService Against Id',
  })
  @ApiResponse({ status: 200, description: 'Successfully retrieved coreservice against id.', type: CoreService })
  @ApiBearerAuth(process.env.X_ACCESS_TOKEN)
  @UseGuards(AuthGuard('jwt'))
  @Get(':id')
  // TODO: Make hashed id's
  async findone(@Param('id') id: number) {
    try {
      const subService = this.coreServicesService.findSubServicesWithCoreServiceID(+id);
      if (!subService) throw new HttpException({ message: `${`CoreService not found with id ${id}`}` }, HttpStatus.NOT_FOUND);
      return subService;
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  @ApiOperation({
    description: 'A successful hit can return CoreService against id',
    summary: 'Update CoreService Against Id',
  })
  @ApiResponse({ status: 200, description: 'Successfully update coreservice against id.', type: CoreService })
  @ApiBearerAuth(process.env.X_ACCESS_TOKEN)
  @UseGuards(AuthGuard('jwt'))
  @Patch(':id')
  // TODO: Make hashed id's
  async update(@Param('id') id: number, @Body() body: UpdateCoreServiceDto) {
    try {
      return this.coreServicesService.update(+id, body);
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  @ApiOperation({
    description: 'A successful hit can delete coreservice against id',
    summary: 'Delete CoreService Against Id',
  })
  @ApiBearerAuth(process.env.X_ACCESS_TOKEN)
  @UseGuards(AuthGuard('jwt'))
  @Delete(':id')
  // TODO: Make hashed id's
  async remove(@Param('id') id: number) {
    try {
      return this.coreServicesService.remove(+id);
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }
}
