import { ApiProperty, PartialType } from '@nestjs/swagger';
import { CreateServiceDto } from './create-service.dto';
import { IsNotEmpty, IsString } from 'class-validator';

export class UpdateServiceDto extends PartialType(CreateServiceDto) {
  @ApiProperty({
    description: 'Name of a Service',
    example: 'Inspection',
  })
  @IsString()
  @IsNotEmpty()
  name: string;
}
