import { ApiProperty } from '@nestjs/swagger';
import { IsString, IsNotEmpty } from 'class-validator';

export class CreateServiceDto {
  @ApiProperty({
    description: 'Name of a Service',
    example: 'Inspection',
  })
  @IsString()
  @IsNotEmpty()
  name: string;
}
