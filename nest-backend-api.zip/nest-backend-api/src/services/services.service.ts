import { BadRequestException, HttpException, HttpStatus, Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Service } from './entities/service.entity';
import { CreateServiceDto } from './dto/create-service.dto';
import { UpdateServiceDto } from './dto/update-service.dto';

@Injectable()
export class ServicesService {
  constructor(@InjectRepository(Service) private servicesRepository: Repository<Service>) {}
  async create(body: CreateServiceDto): Promise<Service> {
    return this.servicesRepository.save(this.servicesRepository.create(body)).catch((err: any) => {
      throw new HttpException(
        {
          message: `${err}`,
        },
        HttpStatus.CONFLICT,
      );
    });
  }

  async findAll(): Promise<Service[]> {
    try {
      return this.servicesRepository.find({ relations: ['coreServices', 'coreServices.subServices'] });
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  async findOneById(id: number): Promise<Service> {
    try {
      return this.servicesRepository.findOne({ where: { id }, relations: ['coreServices', 'coreServices.subServices'] });
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  async findOneByName(name: string): Promise<Service> {
    try {
      return this.servicesRepository.findOne({ where: { name } });
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  async update(id: number, body: UpdateServiceDto): Promise<Service> {
    try {
      const service = await this.findOneById(id);
      this.servicesRepository.merge(service, body);
      return this.servicesRepository.save(service);
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  async remove(id: number) {
    const service = await this.findOneById(id);
    if (service) return this.servicesRepository.delete(id);
    throw new NotFoundException();
  }
  catch(e) {
    throw new BadRequestException(e.message);
  }
}
