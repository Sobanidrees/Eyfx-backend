import { BadRequestException, Body, Controller, Delete, Get, HttpException, HttpStatus, Param, Patch, Post, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { ServicesService } from './services.service';
import { CreateServiceDto } from './dto/create-service.dto';
import { Service } from './entities/service.entity';
import { UpdateServiceDto } from './dto/update-service.dto';
import { CurrentUser } from 'src/utils/decorator/user-decorator';
import { Inspector } from 'src/inspector/entities/inspector.entity';
import { Consumer } from 'src/consumer/entities/consumer.entity';
import { AuthGuard } from '@nestjs/passport';

@ApiTags('Services')
@Controller('services')
export class ServiceController {
  constructor(private servicesService: ServicesService) {}

  @ApiOperation({
    description: 'A successful hit can return service',
    summary: 'Add Service',
  })
  @ApiBearerAuth(process.env.X_ACCESS_TOKEN)
  @UseGuards(AuthGuard('jwt'))
  @Post()
  async create(@Body() body: CreateServiceDto): Promise<Service> {
    try {
      return this.servicesService.create(body);
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  @ApiOperation({
    description: 'A successful hit can return all services',
    summary: 'Get All Services',
  })
  @ApiResponse({ status: 200, description: 'Successfully retrieved All Services.', type: [Service] })
  @ApiBearerAuth(process.env.X_ACCESS_TOKEN)
  @UseGuards(AuthGuard('jwt'))
  @Get()
  async findAll(@CurrentUser() user: Inspector | Consumer): Promise<Service[]> {
    try {
      return this.servicesService.findAll();
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  @ApiOperation({
    description: 'A successful hit can return service against Id',
    summary: 'Get Service Against Id',
  })
  @ApiResponse({ status: 200, description: 'Successfully retrieved service against id.', type: Service })
  @ApiBearerAuth(process.env.X_ACCESS_TOKEN)
  @UseGuards(AuthGuard('jwt'))
  @Get(':id')
  // TODO: Make hashed id's
  async findOne(@Param('id') id: number): Promise<Service> {
    try {
      const service = this.servicesService.findOneById(+id);
      if (!service) throw new HttpException({ message: `${`Service not found with id ${id}`}` }, HttpStatus.NOT_FOUND);
      return service;
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  @ApiOperation({
    description: 'A successful hit can return Service against id',
    summary: 'Update Service Against Id',
  })
  @ApiResponse({ status: 200, description: 'Successfully update service against id.', type: Service })
  @ApiBearerAuth(process.env.X_ACCESS_TOKEN)
  @UseGuards(AuthGuard('jwt'))
  @Patch(':id')
  // TODO: Make hashed id's
  async update(@Param('id') id: number, @Body() body: UpdateServiceDto): Promise<Service> {
    try {
      return this.servicesService.update(+id, body);
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  @ApiOperation({
    description: 'A successful hit can delete service against id',
    summary: 'Delete Service Against Id',
  })
  @ApiBearerAuth(process.env.X_ACCESS_TOKEN)
  @UseGuards(AuthGuard('jwt'))
  @Delete(':id')
  // TODO: Make hashed id's
  async remove(@Param('id') id: number) {
    try {
      return this.servicesService.remove(+id);
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }
}
