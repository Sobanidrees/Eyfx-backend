import { Module } from '@nestjs/common';
import { ServicesService } from './services.service';
import { ServiceController } from './services.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Service } from './entities/service.entity';

@Module({
  imports: [TypeOrmModule.forFeature([Service])],
  controllers: [ServiceController],
  providers: [ServicesService],
  exports: [ServicesService],
})
export class ServicesModule {}
