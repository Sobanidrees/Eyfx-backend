import { Column, PrimaryGeneratedColumn, Entity, BaseEntity, CreateDateColumn, UpdateDateColumn, OneToMany } from 'typeorm';
import { IsString, IsNotEmpty } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
import { ServiceRequest } from 'src/service_request/entities/service_request.entity';
import { CoreService } from 'src/core_services/entities/core_services.entity';

@Entity('service')
export class Service extends BaseEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @ApiProperty({ example: 'Inspection' })
  @IsString()
  @IsNotEmpty()
  @Column({ unique: true })
  name: string;

  @OneToMany(() => CoreService, coreServices => coreServices.service)
  coreServices: CoreService[];

  @OneToMany(() => ServiceRequest, serviceRequest => serviceRequest.service)
  serviceRequests: ServiceRequest[];

  @ApiProperty({ example: '2023-07-19T12:45:48.911Z' })
  @CreateDateColumn({
    type: 'timestamp',
    default: () => 'CURRENT_TIMESTAMP(6)',
  })
  public created_at: Date;

  @ApiProperty({ example: '2023-07-19T12:45:48.911Z' })
  @UpdateDateColumn({
    type: 'timestamp',
    default: () => 'CURRENT_TIMESTAMP(6)',
    onUpdate: 'CURRENT_TIMESTAMP(6)',
  })
  public updated_at: Date;
}
