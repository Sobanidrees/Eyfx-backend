import { Controller, Get, Post, Body, Patch, Param, Delete, BadRequestException, UseGuards } from '@nestjs/common';
import { VehicleService } from './vehicle.service';
import { CreateVehicleDto } from './dto/create-vehicle.dto';
import { UpdateVehicleDto } from './dto/update-vehicle.dto';
import { ApiBearerAuth, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { Vehicle } from './entities/vehicle.entity';
import { AuthGuard } from '@nestjs/passport';
import { CurrentUser } from 'src/utils/decorator/user-decorator';
import { Consumer } from 'src/consumer/entities/consumer.entity';
import { S3Service } from 'src/utils/s3/s3.service';

@ApiTags('Vehicle')
@Controller('vehicle')
export class VehicleController {
  constructor(private readonly vehicleService: VehicleService, private s3Service: S3Service) {}

  @ApiOperation({
    description: 'A successful hit can return vehicle object',
    summary: 'Register Vehicle',
  })
  @ApiBearerAuth(process.env.X_ACCESS_TOKEN)
  @UseGuards(AuthGuard('jwt'))
  @ApiResponse({ status: 201, description: 'Successfully retrieved a Vehicle.', type: Vehicle })
  @Post()
  async create(@Body() body: CreateVehicleDto, @CurrentUser() user: Consumer): Promise<Vehicle> {
    try {
      return this.vehicleService.create(body, user);
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  @ApiOperation({
    description: 'A successful hit can return all Vehicles',
    summary: 'Get All Vehicles',
  })
  @ApiResponse({
    status: 200,
    description: 'Successfully retrieved All Vehicles.',
    type: [Vehicle],
  })
  @Get()
  @ApiBearerAuth(process.env.X_ACCESS_TOKEN)
  @UseGuards(AuthGuard('jwt'))
  async findAll(): Promise<Vehicle[]> {
    try {
      return this.vehicleService.findAll();
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  @ApiOperation({
    description: 'A successful hit can return Vehicle against Id',
    summary: 'Get Vehicles against Id',
  })
  @ApiResponse({ status: 200, description: 'Successfully retrieved Vehicles against Id .', type: Vehicle })
  @ApiBearerAuth(process.env.X_ACCESS_TOKEN)
  @UseGuards(AuthGuard('jwt'))
  @Get(':id')
  async findOne(@Param('id') id: string): Promise<Vehicle> {
    try {
      return this.vehicleService.findOne(+id);
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  @ApiOperation({
    description: 'A successful hit can return Vehicle against Id',
    summary: 'Update Vehicle against Id',
  })
  @ApiResponse({ status: 200, description: 'Successfully update Vehicle against Id .', type: Vehicle })
  @ApiBearerAuth(process.env.X_ACCESS_TOKEN)
  @UseGuards(AuthGuard('jwt'))
  @Patch(':id')
  async update(@Param('id') id: string, @Body() body: UpdateVehicleDto): Promise<Vehicle> {
    try {
      if (body.image) {
        const s3Response = await this.s3Service.uploadFile(body.image);
        if (s3Response.Location) {
          body.image = s3Response.Location;
        }
      }
      return this.vehicleService.update(+id, body);
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  @ApiOperation({
    description: 'A successful hit can delete Vehicle against Id',
    summary: 'Delete Vehicle against Id',
  })
  @ApiBearerAuth(process.env.X_ACCESS_TOKEN)
  @UseGuards(AuthGuard('jwt'))
  @Delete(':id')
  async remove(@Param('id') id: string) {
    try {
      return this.vehicleService.remove(+id);
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }
}
