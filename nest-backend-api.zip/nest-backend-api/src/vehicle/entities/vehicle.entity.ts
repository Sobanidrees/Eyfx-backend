import { Entity, Column, PrimaryGeneratedColumn, CreateDateColumn, UpdateDateColumn, ManyToOne, OneToMany } from 'typeorm';
import { IsString, IsNotEmpty, IsNumber } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
import { Consumer } from 'src/consumer/entities/consumer.entity';
import { ServiceRequest } from 'src/service_request/entities/service_request.entity';

@Entity('vehicle')
export class Vehicle {
  @PrimaryGeneratedColumn()
  id: number;

  @ApiProperty({ example: '2012' })
  @IsString()
  @IsNotEmpty()
  @Column()
  year: string;

  @ApiProperty({ example: 'Audi' })
  @IsString()
  @IsNotEmpty()
  @Column()
  make: string;

  @ApiProperty({ example: 'A8' })
  @IsString()
  @IsNotEmpty()
  @Column()
  model: string;

  @ApiProperty({ example: '1300' })
  @IsString()  @Column({ nullable: true })
  engineCapacity: string;

  @ApiProperty({ example: '13000' })
  @IsString()
  @Column({ nullable: true })
  mileage: string;

  @ApiProperty({ example: 'Petrol' })
  @IsString()
  @Column({ nullable: true })
  fuelType: string;

  @ApiProperty({ example: '1HGCM82633A123456' })
  @IsString()
  @Column({ nullable: true })
  vin: string;

  @ApiProperty({ example: 'G21b2789090' })
  @IsString()
  @Column({ nullable: true })
  engineNo: string;

  @ApiProperty({ example: 'REG-7861' })
  @IsString()
  @Column({ nullable: true })
  registrationNo: string;

  @ApiProperty({ example: 'AUTO' })
  @IsString()
  @Column({ nullable: true })
  transmissionType: string;

  @ApiProperty({ example: 'RED' })
  @IsString()
  @Column({ nullable: true })
  color: string;

  @ApiProperty({ example: 'url' })
  @IsString()
  @Column({ nullable: true })
  image: string;

  @ApiProperty({ example: '2023-07-19T12:45:48.911Z' })
  @CreateDateColumn({
    type: 'timestamp',
    default: () => 'CURRENT_TIMESTAMP(6)',
  })
  public created_at: Date;

  @ApiProperty({ example: '2023-07-19T12:45:48.911Z' })
  @UpdateDateColumn({
    type: 'timestamp',
    default: () => 'CURRENT_TIMESTAMP(6)',
    onUpdate: 'CURRENT_TIMESTAMP(6)',
  })
  public updated_at: Date;

  @ManyToOne(() => Consumer, consumer => consumer.vehicle, { onDelete: 'CASCADE' })
  consumer: Consumer;

  @OneToMany(() => ServiceRequest, serviceRequest => serviceRequest.vehicle)
  serviceRequest: ServiceRequest[];
}
