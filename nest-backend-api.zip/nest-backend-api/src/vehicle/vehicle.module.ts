import { Module, forwardRef } from '@nestjs/common';
import { VehicleService } from './vehicle.service';
import { VehicleController } from './vehicle.controller';
import { Vehicle } from './entities/vehicle.entity';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ConsumerModule } from 'src/consumer/consumer.module';
import { S3Service } from 'src/utils/s3/s3.service';

@Module({
  imports: [TypeOrmModule.forFeature([Vehicle]), forwardRef(() => ConsumerModule)],
  controllers: [VehicleController],
  providers: [VehicleService, S3Service],
  exports: [VehicleService],
})
export class VehicleModule {}
