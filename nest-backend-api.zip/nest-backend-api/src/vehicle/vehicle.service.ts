import { BadRequestException, HttpException, HttpStatus, Injectable, NotFoundException } from '@nestjs/common';
import { CreateVehicleDto } from './dto/create-vehicle.dto';
import { UpdateVehicleDto } from './dto/update-vehicle.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { Vehicle } from './entities/vehicle.entity';
import { Repository } from 'typeorm';
import { Consumer } from 'src/consumer/entities/consumer.entity';

@Injectable()
export class VehicleService {
  constructor(@InjectRepository(Vehicle) private vehicleRepository: Repository<Vehicle>) {}
  async create(body: CreateVehicleDto, consumer: Consumer): Promise<Vehicle> {
    return this.vehicleRepository.save(this.vehicleRepository.create({ ...body, consumer: consumer })).catch((err: any) => {
      throw new HttpException(
        {
          message: `${err}`,
        },
        HttpStatus.CONFLICT,
      );
    });
  }

  async findAll(): Promise<Vehicle[]> {
    try {
      return this.vehicleRepository.find({ relations: ['consumer'] });
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  async findOne(id: number): Promise<Vehicle> {
    try {
      const vehicle = this.vehicleRepository.findOne({ where: { id }, relations: ['consumer'] });
      if (!vehicle) throw new HttpException({ message: `${`Vehicle not found with id ${id}`}` }, HttpStatus.NOT_FOUND);
      return vehicle;
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }


  async update(id: number, body: UpdateVehicleDto): Promise<Vehicle> {
    try {
      const vehicle = await this.findOne(id);
      this.vehicleRepository.merge(vehicle, body);
      return this.vehicleRepository.save(vehicle);
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  async remove(id: number): Promise<Object> {
    try {
      const vehicle = await this.findOne(id);
      if (vehicle) return this.vehicleRepository.delete(id);
      throw new NotFoundException();
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }
}
