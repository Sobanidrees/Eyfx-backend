import { ApiProperty } from '@nestjs/swagger';
import { IsString, IsNotEmpty } from 'class-validator';

export class CreateVehicleDto {
  @ApiProperty({
    example: '2012',
    description: 'Year of a car',
    format: 'string',
  })
  @IsString()
  @IsNotEmpty()
  year: string;

  @ApiProperty({
    example: 'Audi',
    description: 'Make of a car',
    format: 'string',
  })
  @IsString()
  @IsNotEmpty()
  make: string;

  @ApiProperty({
    example: 'A8',
    description: 'Model of a car',
    format: 'string',
  })
  @IsString()
  @IsNotEmpty()
  model: string;
}
