import { ApiProperty } from '@nestjs/swagger';
import { IsNumber, IsString } from 'class-validator';

export class UpdateVehicleDto {
  @ApiProperty({ example: '1300' })
  @IsString()
  engineCapacity: string;

  @ApiProperty({ example: '13000' })
  @IsString()
  mileage: string;

  @ApiProperty({ example: 'Petrol' })
  @IsString()
  fuelType: string;

  @ApiProperty({ example: '1HGCM82633A123456' })
  @IsString()
  vin: string;

  @ApiProperty({ example: 'G21b2789090' })
  @IsString()
  engineNo: string;

  @ApiProperty({ example: 'REG-7861' })
  @IsString()
  registrationNo: string;

  @ApiProperty({ example: 'AUTO' })
  @IsString()
  transmissionType: string;

  @ApiProperty({ example: 'RED' })
  @IsString()
  color: string;

  @ApiProperty({ example: 'url' })
  image: any;
}
