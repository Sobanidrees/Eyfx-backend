import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, CreateDateColumn, UpdateDateColumn } from 'typeorm';
import { ApiProperty } from '@nestjs/swagger';
import { IsBoolean, IsNotEmpty, IsString } from 'class-validator';
import { CoreService } from 'src/core_services/entities/core_services.entity';

@Entity()
export class SubServices {
  @PrimaryGeneratedColumn()
  id: number;

  @ApiProperty({ example: 'Radiator Core Support' })
  @IsString()
  @IsNotEmpty()
  @Column({ unique: true })
  subServiceName: string;

  @Column({ nullable: true })
  parentId?: number;

  @ManyToOne(() => CoreService, coreServices => coreServices.subServices, { onDelete: 'CASCADE' })
  coreServices: CoreService;

  @ApiProperty({ example: '2023-07-19T12:45:48.911Z' })
  @CreateDateColumn({
    type: 'timestamp',
    default: () => 'CURRENT_TIMESTAMP(6)',
  })
  public created_at: Date;

  @ApiProperty({ example: '2023-07-19T12:45:48.911Z' })
  @UpdateDateColumn({
    type: 'timestamp',
    default: () => 'CURRENT_TIMESTAMP(6)',
    onUpdate: 'CURRENT_TIMESTAMP(6)',
  })
  public updated_at: Date;

  @ApiProperty({ example: 'Image object' })
  @IsBoolean()
  @Column({ nullable: false })
  imageable: boolean;
}
