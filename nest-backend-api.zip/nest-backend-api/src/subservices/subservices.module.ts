import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { SubServices } from './entities/subservice.entity';
import { CoreServicesModule } from 'src/core_services/core_services.module';
import { SubservicesController } from './subservices.controller';
import { SubservicesService } from './subservices.service';

@Module({
  imports: [TypeOrmModule.forFeature([SubServices]), CoreServicesModule],
  controllers: [SubservicesController],
  providers: [SubservicesService],
  exports: [SubservicesService]
})
export class SubservicesModule {}
