import { BadRequestException, HttpException, HttpStatus, Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { SubServices } from './entities/subservice.entity';
import { CreateSubServiceDto } from './dto/create-subservice.dto';
import { UpdateSubServiceDto } from './dto/update-subservice.dto';

@Injectable()
export class SubservicesService {
  constructor(@InjectRepository(SubServices) private subServicesRepository: Repository<SubServices>) {}
  async create(body: CreateSubServiceDto): Promise<SubServices> {
    const createdSubService = this.subServicesRepository.create({ subServiceName: body.subServiceName, coreServices: { id: body.coreServiceId }, parentId: body.parentId });
    return this.subServicesRepository.save(createdSubService).catch((err: any) => {
      throw new HttpException(
        {
          message: `${err}`,
        },
        HttpStatus.CONFLICT,
      );
    });
  }

  async findAll(): Promise<SubServices[]> {
    try {
      return this.subServicesRepository.find({relations:['coreServices']});
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  async findOne(id: number): Promise<SubServices> {
    try {
      return this.subServicesRepository.findOne({ where: { id } });
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  async update(id: number, body: UpdateSubServiceDto): Promise<SubServices> {
    try {
      const subSubService = await this.findOne(id);
      this.subServicesRepository.merge(subSubService, body);
      return this.subServicesRepository.save(subSubService);
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  async remove(id: number): Promise<Object> {
    const subSubService = await this.findOne(id);
    if (subSubService) return this.subServicesRepository.delete(id);
    throw new NotFoundException();
  }
  catch(e) {
    throw new BadRequestException(e.message);
  }
}
