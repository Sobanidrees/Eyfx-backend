import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsString } from 'class-validator';
import { Column } from 'typeorm';

export class CreateSubServiceDto {
  @ApiProperty({
    description: 'Service ID of the selected service',
    example: '1',
  })
  @IsNotEmpty()
  readonly coreServiceId: number;

  @ApiProperty({ example: 'null' })
  @Column({ nullable: true })
  parentId?: number;

  @ApiProperty({
    description: 'Name of a SubSubService',
    example: 'Radiator Core Support',
  })
  @IsNotEmpty()
  @IsString()
  subServiceName: string;
}
