import { ApiProperty, PartialType } from '@nestjs/swagger';
import { IsNotEmpty, IsString } from 'class-validator';
import { CreateSubServiceDto } from './create-subservice.dto';

export class UpdateSubServiceDto extends PartialType(CreateSubServiceDto) {
  @ApiProperty({
    description: 'Name of a SubSubService',
    example: 'Radiator Core Support',
  })
  @IsNotEmpty()
  @IsString()
  subSubServiceName: string;
}
