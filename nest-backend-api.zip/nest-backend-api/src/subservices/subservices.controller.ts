import { Controller, Get, Post, Body, Patch, Param, Delete, BadRequestException, HttpException, HttpStatus, UseGuards } from '@nestjs/common';
import { SubServices } from './entities/subservice.entity';
import { ApiBearerAuth, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { AuthGuard } from '@nestjs/passport';
import { SubservicesService } from './subservices.service';
import { CreateSubServiceDto } from './dto/create-subservice.dto';
import { UpdateSubServiceDto } from './dto/update-subservice.dto';

@ApiTags('SubServices')
@Controller('subservices')
export class SubservicesController {
  constructor(private readonly subservicesService: SubservicesService) {}

  @Post()
  @ApiBearerAuth(process.env.X_ACCESS_TOKEN)
  @UseGuards(AuthGuard('jwt'))
  async create(@Body() body: CreateSubServiceDto): Promise<SubServices> {
    try {
      return this.subservicesService.create(body);
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  @ApiOperation({
    description: 'A successful hit can return all subservices',
    summary: 'Get All SubServices',
  })
  @ApiResponse({ status: 200, description: 'Successfully retrieved All SubServices.', type: [SubServices] })
  // @ApiBearerAuth(process.env.X_ACCESS_TOKEN)
  // @UseGuards(AuthGuard('jwt'))
  @Get()
  async findAll(): Promise<SubServices[]> {
    try {
      return this.subservicesService.findAll();
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  @ApiOperation({
    description: 'A successful hit can return subservice against Id',
    summary: 'Get SubService Against Id',
  })
  @ApiResponse({ status: 200, description: 'Successfully retrieved subservice against id.', type: SubServices })
  @ApiBearerAuth(process.env.X_ACCESS_TOKEN)
  @UseGuards(AuthGuard('jwt'))
  @Get(':id')
  // TODO: Make hashed id's
  async findOne(@Param('id') id: number): Promise<SubServices> {
    try {
      const subSubService = this.subservicesService.findOne(+id);
      if (!subSubService) throw new HttpException({ message: `${`SubService not found with id ${id}`}` }, HttpStatus.NOT_FOUND);
      return subSubService;
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  @ApiOperation({
    description: 'A successful hit can return SubService against id',
    summary: 'Update SubService Against Id',
  })
  @ApiResponse({ status: 200, description: 'Successfully update subservice against id.', type: SubServices })
  @ApiBearerAuth(process.env.X_ACCESS_TOKEN)
  @UseGuards(AuthGuard('jwt'))
  @Patch(':id')
  // TODO: Make hashed id's
  async update(@Param('id') id: number, @Body() body: UpdateSubServiceDto): Promise<SubServices> {
    try {
      return this.subservicesService.update(+id, body);
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  @ApiOperation({
    description: 'A successful hit can delete subservice against id',
    summary: 'Delete SubService Against Id',
  })
  @ApiBearerAuth(process.env.X_ACCESS_TOKEN)
  @UseGuards(AuthGuard('jwt'))
  @Delete(':id')
  // TODO: Make hashed id's
  async remove(@Param('id') id: number) {
    try {
      return this.subservicesService.remove(+id);
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }
}
