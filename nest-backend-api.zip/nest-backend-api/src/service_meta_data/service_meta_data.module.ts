import { Module } from '@nestjs/common';
import { ServiceMetaDataService } from './service_meta_data.service';
import { ServiceMetaDataController } from './service_meta_data.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ServiceMetaData } from './entities/service_meta_data.entity';
import { ServiceRequestModule } from 'src/service_request/service_request.module';

@Module({
  imports: [TypeOrmModule.forFeature([ServiceMetaData]), ServiceRequestModule],
  controllers: [ServiceMetaDataController],
  providers: [ServiceMetaDataService],
})
export class ServiceMetaDataModule {}
