import { Controller, Get, Post, Body, Patch, Param, Delete, BadRequestException } from '@nestjs/common';
import { ServiceMetaDataService } from './service_meta_data.service';
import { CreateServiceMetaDatumDto } from './dto/create-service_meta_datum.dto';
import { ApiTags } from '@nestjs/swagger';

@Controller('service-meta-data')
@ApiTags('ServiceMetaDataController')
export class ServiceMetaDataController {
  constructor(private readonly serviceMetaDataService: ServiceMetaDataService) {}

  @Post()
  create(@Body() body: CreateServiceMetaDatumDto) {
    return this.serviceMetaDataService.create(body);
  }

  @Get(':id')
  findAll(@Param('id') id: string) {
    return this.serviceMetaDataService.findAll(+id);
  }
  @Delete(':id')
  async remove(@Param('id') id: number) {
    try {
      return this.serviceMetaDataService.remove(+id);
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }
}
