import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsString } from 'class-validator';
import { CoreServiceStatus } from 'src/utils/constant/constants';

export class CreateServiceMetaDatumDto {
  @ApiProperty({ example: 'Body Frame Accident Checklist' })
  @IsString()
  @IsNotEmpty()
  coreServiceName: string;

  @ApiProperty({ example: 'Complete' })
  @IsNotEmpty()
  status: CoreServiceStatus;

  @ApiProperty({ example: 1 })
  @IsNotEmpty()
  serviceRequestId: number;
}
