import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsString } from 'class-validator';
import { ServiceRequest } from 'src/service_request/entities/service_request.entity';
import { CoreServiceStatus } from 'src/utils/constant/constants';
import { Column, CreateDateColumn, Entity, ManyToOne, PrimaryGeneratedColumn, UpdateDateColumn } from 'typeorm';

@Entity('serviceMetaData')
export class ServiceMetaData {
  @PrimaryGeneratedColumn()
  id: number;

  @ApiProperty({ example: 'Body Frame Accident Checklist' })
  @IsString()
  @IsNotEmpty()
  @Column()
  coreServiceName: string;

  @ApiProperty({ example: 'Completed' })
  @IsNotEmpty()
  @Column()
  status: CoreServiceStatus;

  @ManyToOne(() => ServiceRequest, serviceRequest => serviceRequest.metaData, { onDelete: 'SET NULL' })
  serviceRequest: ServiceRequest;  

  @ApiProperty({ example: '2023-07-19T12:45:48.911Z' })
  @CreateDateColumn({
    type: 'timestamp',
    default: () => 'CURRENT_TIMESTAMP(6)',
  })
  public created_at: Date;

  @ApiProperty({ example: '2023-07-19T12:45:48.911Z' })
  @UpdateDateColumn({
    type: 'timestamp',
    default: () => 'CURRENT_TIMESTAMP(6)',
    onUpdate: 'CURRENT_TIMESTAMP(6)',
  })
  public updated_at: Date;
}
