import { BadRequestException, HttpException, HttpStatus, Injectable, NotFoundException } from '@nestjs/common';
import { CreateServiceMetaDatumDto } from './dto/create-service_meta_datum.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { ServiceMetaData } from './entities/service_meta_data.entity';
import { ServiceRequestService } from 'src/service_request/service_request.service';

@Injectable()
export class ServiceMetaDataService {
  constructor(@InjectRepository(ServiceMetaData) private serviceMetaDataRepository: Repository<ServiceMetaData>, private readonly serviceRequestService: ServiceRequestService) {}
  async create(body: CreateServiceMetaDatumDto) {
    return this.serviceMetaDataRepository
      .save(
        this.serviceMetaDataRepository.create({
          ...body,
          serviceRequest: {
            id: body.serviceRequestId,
          },
        }),
      )
      .catch((err: any) => {
        throw new HttpException(
          {
            message: `${err}`,
          },
          HttpStatus.CONFLICT,
        );
      });
  }

  async findAll(id: number) {
    try {
      return this.serviceMetaDataRepository.find({
        where: {
          serviceRequest: {
            id: id,
          },
        },
      });
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }
  
  async remove(id: number): Promise<Object> {
    const subService = await this.serviceMetaDataRepository.findOne({ where: { id } });
    if (subService) return this.serviceMetaDataRepository.delete(id);
    throw new NotFoundException();
  }
  catch(e) {
    throw new BadRequestException(e.message);
  }
}
