import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsNumber, IsString } from 'class-validator';
import { IsEmiratesId } from 'src/utils/decorator/emirates-id.decorator';
import { IsPhoneNumber } from 'src/utils/decorator/phone-number.decorator';

export class CreateInspectorJwtDto {
  @ApiProperty({
    example: '+971123456789',
    description: 'The phone number of the account',
    format: 'string',
  })
  @IsString()
  @IsNotEmpty()
  @IsPhoneNumber()
  phoneNumber: string;

  @ApiProperty({
    example: '2',
  })
  @IsNumber()
  id: number;

  @ApiProperty({
    example: 'M Soban Idrees',
    description: 'Name of Inspector',
    format: 'string',
  })
  @IsString()
  @IsNotEmpty()
  fullName: string;

  @ApiProperty({
    example: '784-1234-1234567-1',
    description: 'Emirates id of inspector',
    format: 'string',
  })
  @IsString()
  @IsNotEmpty()
  @IsEmiratesId()
  emiratesId: string;
}
