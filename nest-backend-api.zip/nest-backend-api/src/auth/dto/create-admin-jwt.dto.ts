import { ApiProperty } from '@nestjs/swagger';
import { IsEmail, IsNotEmpty, IsNumber, IsString } from 'class-validator';
import { IsFullName } from 'src/utils/decorator/full-name.decorator';

export class CreateAdminJwtDto {
  @ApiProperty({ example: 'msobanidrees@gmail.com' })
  @IsString()
  @IsNotEmpty()
  @IsEmail()
  email: string;

  @ApiProperty({ example: 'msobanidrees@gmail.com' })
  @IsNumber()
  id: number;

  @ApiProperty({ example: 'soban' })
  @IsString()
  @IsNotEmpty()
  @IsFullName()
  fullName: string;
}
