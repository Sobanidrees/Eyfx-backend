import { Controller, Post, Req, UnauthorizedException, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { Admin } from 'src/admin/entities/admin.entity';
import { Consumer } from 'src/consumer/entities/consumer.entity';
import { Inspector } from 'src/inspector/entities/inspector.entity';
import { CurrentUser } from 'src/utils/decorator/user-decorator';
import { JwtAuthGuard } from './jwt-auth.gaurd';
import { AuthService } from './auth.service';
import { Request } from 'express';

@ApiTags('Auth')
@Controller('auth')
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  @UseGuards(JwtAuthGuard)
  @Post('logout')
  @ApiBearerAuth(process.env.X_ACCESS_TOKEN)
  async logout(@Req() request: Request, @CurrentUser() user: Consumer | Admin | Inspector) {
    const authorizationHeader = request.headers['authorization'];
    if (!authorizationHeader || !authorizationHeader.startsWith('Bearer ')) {
      throw new UnauthorizedException('Invalid or missing Authorization header');
    }
    const token = authorizationHeader.split(' ')[1];
    this.authService.revokeToken(token);
    return 'User logged out Successfully';
  }
}
