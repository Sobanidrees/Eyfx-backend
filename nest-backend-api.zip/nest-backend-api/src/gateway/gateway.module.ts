import { Module } from '@nestjs/common';
import { GatewayService } from './gateway.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ServiceRequest } from 'src/service_request/entities/service_request.entity';

@Module({
  imports:[TypeOrmModule.forFeature([ServiceRequest])],
  providers: [GatewayService],
  exports:[GatewayService]
})
export class GatewayModule {}
