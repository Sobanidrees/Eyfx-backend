import { WebSocketGateway, WebSocketServer } from '@nestjs/websockets';
import { Server } from 'socket.io';
import { ServiceRequest } from 'src/service_request/entities/service_request.entity';

@WebSocketGateway({ cors: '*' })
export class GatewayService {
  @WebSocketServer()
  server: Server;
  notifyAdminsNewServiceRequest(requestData: ServiceRequest) {
    this.server.emit('newServiceRequest', requestData);
  }
  updateServiceRequestStatus(requestData: ServiceRequest) {
    this.server.emit('newUpdateServiceRequest', requestData);
  }

}
