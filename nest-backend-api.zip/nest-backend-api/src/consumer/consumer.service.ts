import { BadRequestException, HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { CreateConsumerDto } from './dto/create-consumer.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { Consumer } from './entities/consumer.entity';
import { Not, Repository } from 'typeorm';
import { UpdateConsumerDto } from './dto/update-consumer.dto';
import { Vehicle } from 'src/vehicle/entities/vehicle.entity';
import { VehicleService } from 'src/vehicle/vehicle.service';
import { Status } from 'src/utils/constant/constants';

@Injectable()
export class ConsumerService {
  constructor(
    @InjectRepository(Consumer) private consumerRepository: Repository<Consumer>,
    private readonly vehicleService: VehicleService,
    @InjectRepository(Vehicle) private vehicleRepository: Repository<Vehicle>,
  ) {}
  async create(body: CreateConsumerDto): Promise<Consumer> {
    return this.consumerRepository.save(this.consumerRepository.create(body)).catch((err: any) => {
      throw new HttpException(
        {
          message: `${err}`,
        },
        HttpStatus.CONFLICT,
      );
    });
  }

  async update(id: number, body: UpdateConsumerDto): Promise<Consumer> {
    try {
      const consumer = await this.findOneById(id);
      this.consumerRepository.merge(consumer, body);
      return this.consumerRepository.save(consumer);
    } catch (e) {
      throw new HttpException(e.message, e.statusCode);
    }
  }

  async findAll(): Promise<Consumer[]> {
    try {
      return this.consumerRepository.find();
    } catch (e) {
      throw new HttpException(e.message, e.statusCode);
    }
  }

  async findOneByPhoneNumber(phoneNumber: string): Promise<Consumer> {
    try {
      return this.consumerRepository.findOne({
        where: {
          phoneNumber,
        },
        relations: ['vehicle'],
      });
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  async findOneById(id: number): Promise<Consumer> {
    try {
      let consumer = await this.consumerRepository.findOne({
        where: {
          id
        },
        relations: ['vehicle'],
      });
      return consumer;
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }
}
