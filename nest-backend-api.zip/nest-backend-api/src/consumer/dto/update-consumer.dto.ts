import { ApiProperty } from '@nestjs/swagger';
import { IsString } from 'class-validator';
import { IsFullName } from 'src/utils/decorator/full-name.decorator';

export class UpdateConsumerDto {
  @ApiProperty({
    example: 'M Soban Idrees',
    description: 'Name of consumer',
    format: 'string',
  })
  @IsString()
  @IsFullName()
  fullName: string;

  @ApiProperty({
    example: 'House # 5, Street # 5, Younispurah, Lahore ',
    description: 'Address of consumer',
    format: 'string',
  })
  @IsString()
  address: string;
}
