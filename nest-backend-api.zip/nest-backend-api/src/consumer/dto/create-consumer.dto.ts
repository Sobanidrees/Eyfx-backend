import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsString } from 'class-validator';
import { IsFullName } from 'src/utils/decorator/full-name.decorator';
import { IsPhoneNumber } from 'src/utils/decorator/phone-number.decorator';

export class CreateConsumerDto {
  @ApiProperty({
    example: '+971123456789',
    description: 'The phone number of the account',
    format: 'string',
  })
  @IsString()
  @IsNotEmpty()
  @IsPhoneNumber()
  phoneNumber: string;

  @ApiProperty({
    example: 'M Soban Idrees',
    description: 'Name of consumer',
    format: 'string',
  })
  @IsString()
  @IsFullName()
  fullName: string;

  @ApiProperty({
    example: 'House # 5, Street # 5, Younispurah, Lahore ',
    description: 'Address of consumer',
    format: 'string',
  })
  @IsString()
  address: string;
}
