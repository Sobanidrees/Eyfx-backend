import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsString } from 'class-validator';

export class UpdateConsumerVehicleDto {
  @ApiProperty({ example: '2012' })
  @IsString()
  @IsNotEmpty()
  year: string;

  @ApiProperty({ example: 'Audi' })
  @IsString()
  @IsNotEmpty()
  make: string;

  @ApiProperty({ example: 'A8' })
  @IsString()
  @IsNotEmpty()
  model: string;
}
