import { Module } from '@nestjs/common';
import { ConsumerService } from './consumer.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Consumer } from './entities/consumer.entity';
import { ConsumerController } from './consumer.controller';
import { AuthModule } from 'src/auth/auth.module';
import { OtpModule } from 'src/utils/otp/otp.module';
import { ServiceRequest } from 'src/service_request/entities/service_request.entity';
import { VehicleModule } from 'src/vehicle/vehicle.module';
import { Vehicle } from 'src/vehicle/entities/vehicle.entity';

@Module({
  imports: [TypeOrmModule.forFeature([Consumer, ServiceRequest, Vehicle]), AuthModule, OtpModule, VehicleModule],
  providers: [ConsumerService],
  exports: [ConsumerService],
  controllers: [ConsumerController],
})
export class ConsumerModule {}
