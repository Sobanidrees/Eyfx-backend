import { Controller, Get, Post, Body, UseGuards, BadRequestException, UnauthorizedException, Patch, HttpException, HttpStatus, Param } from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { AuthService } from 'src/auth/auth.service';
import { VerifyOtpDto } from '../utils/otp/dto/verify-otp-dto';
import { OtpService } from 'src/utils/otp/otp.service';
import { ReSendOtpDto } from 'src/utils/otp/dto/resend-otp.dto';
import { ConsumerService } from './consumer.service';
import { Consumer } from './entities/consumer.entity';
import { CreateConsumerDto } from './dto/create-consumer.dto';
import { LoginDto } from 'src/auth/dto/login-dto';
import { CurrentUser } from 'src/utils/decorator/user-decorator';
import { InjectRepository } from '@nestjs/typeorm';
import { Not, Repository } from 'typeorm';
import { ServiceRequest } from 'src/service_request/entities/service_request.entity';
import { Status } from 'src/utils/constant/constants';
import { JwtAuthGuard } from 'src/auth/jwt-auth.gaurd';
import { UpdateConsumerDto } from './dto/update-consumer.dto';
import { UpdateConsumerVehicleDto } from './dto/update-consumer-vehicle.dto';
import { Vehicle } from 'src/vehicle/entities/vehicle.entity';

@ApiTags('Consumer')
@Controller('consumer')
export class ConsumerController {
  constructor(
    private readonly consumerService: ConsumerService,
    private readonly authService: AuthService,
    private readonly otpService: OtpService,
    @InjectRepository(ServiceRequest) private serviceRequestRepository: Repository<ServiceRequest>,
    @InjectRepository(Vehicle) private vehicleRepository: Repository<Vehicle>,
  ) {}

  @ApiOperation({
    description: 'A successful hit can return consumer object',
    summary: 'Register Consumer',
  })
  @ApiResponse({ status: 201, description: ' Successfully created consumer.', type: Consumer })
  @Post('/register')
  async create(@Body() body: CreateConsumerDto): Promise<Consumer> {
    try {
      const consumer = await this.consumerService.findOneByPhoneNumber(body.phoneNumber);
      if (!consumer) {
        return this.consumerService.create(body);
      }
      return consumer;
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  @ApiOperation({
    description: 'A successful hit can return consumer',
    summary: 'Login Consumer',
  })
  @ApiResponse({ status: 200, description: 'Add Otp please.....', type: Consumer })
  @Post('/login')
  async login(@Body() body: LoginDto): Promise<Consumer> {
    try {
      let consumer = await this.consumerService.findOneByPhoneNumber(body.phoneNumber);
      if (!consumer) {
        consumer = await this.consumerService.create({ address: null, fullName: null, phoneNumber: body.phoneNumber });
      }
      this.otpService.generateAndSendOTP(body.phoneNumber);
      const customer = this.consumerService.findOneById(consumer.id);
      return customer;
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }
  @ApiOperation({
    description: 'A successful hit can return JWT token',
    summary: 'Verify OTP',
  })
  @ApiResponse({ status: 200, description: 'Success' })
  @Post('verify_otp')
  async verify_otp(@Body() body: VerifyOtpDto): Promise<string> {
    try {
      const consumer = await this.consumerService.findOneByPhoneNumber(body.phoneNumber);
      if (!consumer) throw new UnauthorizedException('Invalid phone number');
      const otp = await this.otpService.findWithPhoneNumberAndOtp({ phoneNumber: body.phoneNumber, otp: body.otp });
      if (!otp) throw new UnauthorizedException('Invalid otp');
      await this.otpService.remove(otp.id);
      return this.authService.generateTokenForConsumer({ id: consumer.id, phoneNumber: consumer.phoneNumber, fullName: consumer.fullName, address: consumer.address });
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }
  @ApiOperation({
    description: 'A successful hit can return new otp',
    summary: 'Resend OTP',
  })
  @ApiResponse({ status: 200, description: 'Successfully receive new Otp' })
  @Post('resend_otp')
  async resend_otp(@Body() body: ReSendOtpDto): Promise<string> {
    try {
      return this.otpService.generateAndSendOTP(body.phoneNumber);
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  @ApiOperation({
    description: 'A successful hit can return all Consumers',
    summary: 'Get All Consumers',
  })
  @ApiResponse({
    status: 200,
    description: 'Successfully retrieved All consumer.',
    type: [Consumer],
  })
  @Get()
  @ApiBearerAuth(process.env.X_ACCESS_TOKEN)
  @UseGuards(JwtAuthGuard)
  async findAll() {
    try {
      return await this.consumerService.findAll();
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  @ApiOperation({
    description: 'A successful hit can return all Consumers Service requests that are not completed',
    summary: 'Get All Not Completed Servive Request Consumers',
  })
  @ApiResponse({
    status: 200,
    description: 'Successfully retrieved SRs.',
    type: [ServiceRequest],
  })
  @Get('ConsumerSrStatus/:id')
  @ApiBearerAuth(process.env.X_ACCESS_TOKEN)
  @UseGuards(JwtAuthGuard)
  async getConsumerPendingSRs(@Param('id') id: string): Promise<ServiceRequest[]> {
    console.log('in here', id);
    try {
      return await this.serviceRequestRepository.find({
        where: {
          consumer: {
            id: +id,
          },
          status: Not(Status.Completed),
        },
        relations: ['inspector'],
      });
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  @ApiOperation({
    description: 'A successful hit can return updated Consumer',
    summary: 'Update Consumer Profile',
  })
  @ApiResponse({ status: 200, description: 'Successfully update Consumer .', type: Consumer })
  @ApiBearerAuth(process.env.X_ACCESS_TOKEN)
  @UseGuards(JwtAuthGuard)
  @Patch('update_Profile')
  async updateConsumerProfile(@CurrentUser() user: Consumer, @Body() body: UpdateConsumerDto): Promise<Consumer> {
    try {
      return this.consumerService.update(user.id, body);
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }

  @ApiOperation({
    description: 'A successful hit can return updated Vehicle',
    summary: 'Update Vehicle',
  })
  @ApiResponse({ status: 200, description: 'Successfully update Vehicle .', type: Vehicle })
  @ApiBearerAuth(process.env.X_ACCESS_TOKEN)
  @UseGuards(JwtAuthGuard)
  @Patch('update_Vehicle')
  async updateVehicle(@CurrentUser() user: Consumer, @Body() body: UpdateConsumerVehicleDto): Promise<Consumer> {
    try {
      await this.vehicleRepository.save(
        this.vehicleRepository.create(
          { ...body, consumer: { id: user.id } }
        ))
        .catch((err: any) => {
          throw new HttpException(
            {
              message: `${err}`,
            },
            HttpStatus.CONFLICT,
          );
      });
      const consumer = await this.consumerService.findOneById(user.id);
      return consumer;
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  }
}
